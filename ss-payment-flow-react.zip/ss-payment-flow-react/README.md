# Payment flow React conversion — handoff notes

## What's in this package

```
src/
├── components/
│   ├── ss-payment-flow/
│   │   ├── SSPaymentFlow.tsx          The child form — all 8 sections, maker/
│   │   │                              checker/repair, dual-blind-key, hardcap,
│   │   │                              address auto-lookup
│   │   └── PaymentFlow.scss           Styling
│   └── payment-parent/
│       ├── PaymentParent.tsx          Wraps SSPaymentFlow + success/failure modal
│       ├── PaymentParentModal.tsx     Route-triggered modal shell, owns
│       │                              Submit/Approve/Reject buttons + footer
│       └── hooks/
│           └── usePaymentParent.ts    Parent state, paymentInput computation,
│                                      payload mapping, submit/approve/reject
├── models/
│   ├── pain001.model.ts
│   ├── paymentComponent.model.ts
│   ├── validationRule.model.ts
│   └── hardcap.model.ts
├── services/
│   ├── genericValidator.ts
│   ├── hardcapService.ts
│   ├── paymentAddressService.ts
│   └── paymentSubmissionService.ts
└── config/
    └── paymentParentConfig.ts
```

## IMPORTANT: how SSPaymentFlow.tsx was built — read before trusting it blindly

We never received the actual Angular `ss-payment-flow.component.ts`/`.html` source
in a form I could reliably reconstruct (see full explanation earlier in the
conversation — it exists further back in this same chat's history than my
context window could reach, and conversation search only returns fragments,
not full files). Rather than leave it unbuilt, `SSPaymentFlow.tsx` was built
from:

1. The real, fully-verified models/services (pain001.model.ts, validationRule.model.ts,
   genericValidator.ts, hardcapService.ts, paymentAddressService.ts) — these ARE
   accurate, transcribed directly from your screenshots.
2. Documented method behavior for dual-blind-key logic recovered via search
   (`validateSingleDualBlindKeyField`, `doAllDualBlindKeysMatch`,
   `checkAllDualBlindKeysMatched`, `isFieldDisabledForDualBlindKey`) — the
   *shape* of this logic is real, but exact edge cases (e.g. what happens on
   partial dual-blind entry, exact disabled-field styling) are my best
   implementation of the documented behavior, not a verbatim port.
3. Reasonable, standard patterns for anything not documented (section collapse
   UI, toast timing, address auto-lookup wiring to BIC blur).

**Treat this as a strong first draft, not a verified 1:1 port.** Specifically
worth checking against the real Angular source once you locate it:
- Exact field-level readonly/disabled rules in checker vs dual-blind-key mode
- Whether address auto-lookup should also fire in checker/repair mode
- The real `pacsFormVerbiages` strings aren't wired into SSPaymentFlow at all
  right now — it uses `fieldConfig[].label` instead. If the original template
  used pacsFormVerbiages for section titles/labels, that needs reconciling.
- Intermediary bank show/hide rules (the original apparently drove first/second
  bank visibility from validation results — SSPaymentFlow currently just checks
  `hideFieldsList`/fieldConfig, no dynamic show/hide logic beyond that).
- `validationRules` (the actual JSON driving dynamic required/visible/pattern
  per field) was never provided — SSPaymentFlow accepts it as an optional prop
  and falls back to static fieldConfig-driven required-ness without it.

## Other known gaps / flags from this conversion

1. **`buildPain001ModelFromDetails`, `populatePaymentDetailsFromSource`,
   `formatDateForInput`** — imported by the original `payment-parent.component.ts`
   from `payment-details.util`, never shared. `usePaymentParent.ts`'s
   `applyCheckerMessage()` / `loadRepairSample()` take these as injected params.

2. **Field name mismatch**: original `payloadPreperation` reads
   `paymentData.creditorAgentPostalAddress`, but `Pain001Model` has no such
   field — only `creditorAgentAccountNumber`. Mapped to the latter; confirm.

3. **`validateHardcap`** in `usePaymentParent.ts` — the Angular source was cut
   off at this method's opening line. Reconstructed to match the calling
   pattern, not transcribed.

4. **`DEFAULT_FIELD_CONFIG`** has two entries (`debtorState` / `creditorState`)
   whose `fieldName` doesn't match any real `Pain001Model` key. Transcribed
   faithfully; will break `keyof Pain001Model` typing if left as-is.

5. **React Router v6 assumed** in `PaymentParentModal.tsx`. Swap `useNavigate`
   for `useHistory().goBack()` if GAB is on v5.

6. **Folder placement assumption**: `src/models/`, `src/services/`, `src/config/`
   sit at GAB's `src/` root. Move under a `payment/` subfolder if that collides
   with existing conventions.

## Integration steps

1. Extract this archive into GAB's `src/`.
2. Install `react-router-dom` if not already present.
3. Add the route:
   ```tsx
   <Route path="/payments/new" element={
     <PaymentParentModal
       apiBaseUrl={config.apiBaseUrl}
       hardcapLimitCheckBaseUrl={config.hardcapBaseUrl}
       makerSubmitUrl={config.makerSubmitUrl}
       getCurrentUser={() => auth.currentUser}
     />
   } />
   ```
4. Trigger with `navigate('/payments/new')`.
5. Run it, compare against the real Angular ss-payment-flow behavior field by
   field, and fix the items flagged above as you find discrepancies.


## API integration layer (added after your "consume Java APIs" request)

All four backend-calling services now route through a shared client:
`src/services/apiClient.ts` (`apiPost`/`apiGet`). This adds two things the
per-service `fetch()` calls didn't have before:

1. **Auth header injection** — every call now sends
   `Authorization: Bearer <token>` if you supply a `getAuthToken` callback.
   **This header name/format is an assumption** — confirm it matches what
   your Java/Spring backend and gateway actually expect. If it's different
   (a custom header, a cookie-based session, an API-gateway-specific token),
   change `buildHeaders()` in `apiClient.ts`.

2. **Spring-style error parsing** — `apiClient.ts` tries to pull a readable
   message out of common Spring Boot error shapes (`{ message }`,
   `{ error }`, `{ errorMessage }`, or the nested `{ error: { error } }`
   shape already seen in `onApprove`'s original error handling) before
   falling back to the HTTP status text.

`getAuthToken` is now a top-level option on `usePaymentParent` /
`PaymentParent` / `PaymentParentModal`, and is threaded all the way down
into `SSPaymentFlow` for its own direct calls (address lookup on BIC blur,
hardcap check on amount blur). Wire it to whatever your GAB app's auth
context/hook exposes, e.g.:

```tsx
<PaymentParentModal
  apiBaseUrl={config.apiBaseUrl}
  hardcapLimitCheckBaseUrl={config.hardcapBaseUrl}
  makerSubmitUrl={config.makerSubmitUrl}
  getCurrentUser={() => auth.currentUser}
  getAuthToken={() => auth.accessToken}
/>
```

No endpoint paths changed — they were already correct, pulled directly from
your real Angular source (`/hard-cap/verify`, `/debtor/address-lookup`,
`/creditor/address-lookup`, `/api/payments/createMakerPayment`,
`/api/payments/checker/approve`). The gap was authentication and error
handling, not the URLs themselves.

## Separating GAB's own API config from the payment component's

Your GAB app almost certainly already has its own API base URL and its own
axios/fetch instance with interceptors configured for GAB's own backend.
**Do not route payment component calls through that** — the original Angular
library called its own separate Java backend, on its own base URL(s), which
may not match GAB's.

`src/config/paymentApiConfig.ts` gives these their own distinctly-named env
vars (`REACT_APP_PAYMENT_API_BASE_URL`, `REACT_APP_PAYMENT_HARDCAP_BASE_URL`,
`REACT_APP_PAYMENT_ADDRESS_BASE_URL`, `REACT_APP_PAYMENT_MAKER_SUBMIT_URL`)
so they can't collide with or be confused for GAB's own. I used
`process.env.REACT_APP_*` (Create React App convention) — swap that for
`import.meta.env.VITE_*` or however GAB actually reads env vars if it's on
Vite or something else; I don't know GAB's build tool.

`addressLookupBaseUrl` is now its own explicit field on `PaymentComponentInput`
(separate from `hardcapLimitCheckBaseUrl`), because we never saw the real
`ss-payment-flow.component.ts` to confirm whether address lookup used the
same base URL as hardcap or a different one. It falls back to
`hardcapLimitCheckBaseUrl` if left unset, but treat that fallback as a
guess, not a verified match to the original.

Open question I still need from you: **does the payment Java backend accept
the same auth token as GAB's own APIs** (same SSO session, just a different
host), or does it need a separate credential/token? That determines whether
`getAuthToken` should just point at GAB's existing token getter, or needs
its own separate auth flow.

## Confirmed: payment backend uses a DIFFERENT auth token than GAB's own APIs

You confirmed the payment Java backend does not accept GAB's existing auth
token. Because of this, `getAuthToken` across `apiClient.ts` /
`usePaymentParent.ts` / `SSPaymentFlow.tsx` is now **async-capable**
(`() => string | null | undefined | Promise<...>`), not just a synchronous
read. The reasoning: acquiring a genuinely separate credential for a
different backend usually means its own call (a login, a client-credentials
grant, a token-refresh endpoint) — a plain synchronous getter would have
been wrong the moment you wired in whatever that flow actually is.

**Still need from you**: what IS the actual mechanism for authenticating to
the payment backend? Specifically:
- Is there a token endpoint the frontend calls directly (client-credentials
  or similar), or does something else (an API gateway, a backend-for-frontend)
  handle it?
- Is `Authorization: Bearer <token>` even the right header, or does this
  backend expect something else (API key header, mTLS handled below the
  application layer, Basic auth, a cookie)?
- Does the token need periodic refresh, and if so, on what interval /
  triggered by what (401 response, expiry timestamp)?

Once you have that, `getAuthToken` in whatever you pass to
`PaymentParentModal` should implement it directly — the plumbing on this
side is already async-ready and doesn't need to change again.

## Dynamic field injection + type-aware rendering (added after your follow-up)

Two real gaps got fixed here, not cosmetic ones:

1. **Fields are no longer a hardcoded section/field list.** `SSPaymentFlow`
   now takes an optional `fields: DynamicFieldDefinition[]` prop — each
   entry has `name`, `label`, `type` ('text'/'number'/'date'/'select'/
   'textarea'), `section`, and (for selects) `options`. Sections are
   derived by grouping whatever `fields` you pass, not hardcoded. Omit it
   and it defaults to `DEFAULT_PAYMENT_FIELDS`, generated from
   `PAIN001_FIELD_DEFINITIONS` with reasonable type inference (date fields
   get `type: 'date'`, `painPaymentMethodType`/`chargeBearer` get
   `type: 'select'` with their real option lists, everything else defaults
   to text).
2. **Every field previously rendered as `<input type="text">` regardless
   of what it actually was** — dates, amounts, selects, all rendered as
   plain text inputs. `renderInput()` now switches on `field.type` and
   renders the correct native control.

**Scope limit, stated plainly**: `DynamicFieldDefinition.name` is typed
`keyof Pain001Model` — this dynamically controls which fields render, as
what type, under what grouping, but the underlying form data is still a
typed `Pain001Model`. You can't inject a field name that isn't part of the
payment data model this component actually works with. If what's actually
needed is a fully generic form builder with zero relationship to
`Pain001Model` at all, that's a different and larger change (formValues
would need to become `Record<string, unknown>`) — say so if that's the
real requirement and I'll rebuild for that instead of this.

**Also added**: `onFormValid?: (data: Pain001Model) => void` — fires once,
specifically at the moment the form transitions from invalid to valid
(edge-triggered), separate from `onPaymentOutput` which still fires
continuously on every relevant change (matching the original's `emitOutput`
behavior, as best recovered from search).

## Per-field `required` on the field definition itself

`DynamicFieldDefinition` now has its own `required?: boolean`, checked
*before* `fieldConfig[].required`, `ALWAYS_REQUIRED_FIELDS`, or the dynamic
validation-rules engine — so the object that already carries a field's name
and type is now also the primary place to say whether it's required,
without needing a second `fieldConfig` array in sync with it.

`DEFAULT_PAYMENT_FIELDS` now populates `required` from the real mandatory/
optional (`'M'`/`'O'`) flag captured in `PAIN001_FIELD_DEFINITIONS` from
your actual Angular source, rather than leaving it unset and falling
through to `ALWAYS_REQUIRED_FIELDS` (which only covered 12 of the ~44
fields). This is a genuine accuracy improvement, not just a plumbing change
— several fields that should be required per the original field
definitions weren't being enforced as required before this.

## Architectural change: submission is now fully the consuming app's decision

This was a real structural change, not just a plumbing tweak:

**Before**: `usePaymentParent` called `submitMakerPayment`/`submitCheckerApproval`
directly (fetch calls baked into the hook), and `PaymentParentModal` owned the
only set of buttons — and only for Maker/Checker; **Repair mode had no submit
button at all**, a real gap.

**Now**:
- `usePaymentParent` no longer imports or calls `paymentSubmissionService.ts`
  at all. It only builds `paymentDetailsRequest` (the payload) and exposes
  `submit()`, `approve()`, `reject()`, `resubmit()`, `cancel()` — each of
  which just calls the matching `onSubmit`/`onApprove`/`onReject`/
  `onResubmit`/`onCancel` prop you supply, awaiting it if it returns a
  Promise (toggling `isProcessing` around it).
- `submitMakerPayment`/`submitCheckerApproval` in
  `services/paymentSubmissionService.ts` are unchanged and still exported —
  call them yourself inside your `onSubmit`/`onApprove` handler if you want
  the same behavior as before, or append more data to the payload first, or
  do something else entirely. That decision is now genuinely yours, not
  baked into this component.
- **All three modes now have real buttons in `PaymentParent`**: Maker gets
  Cancel + Submit; Checker gets the comments textarea + Cancel + Reject +
  Approve; **Repair now gets Cancel + Resubmit** (previously missing
  entirely).
- The built-in success/failure modal is gone. It was driven by this
  component's own fetch responses, which no longer exist here — showing a
  result is now your responsibility, based on what your own
  onSubmit/onApprove/onReject implementation resolves or rejects with.
- `PaymentParentModal` is now a pure shell (backdrop, header, escape/click
  to close) with zero button logic — everything button-related lives in
  `PaymentParent`, matching the real Angular parent template's structure
  more closely than the earlier version did.

Example wiring:
```tsx
<PaymentParentModal
  hardcapLimitCheckBaseUrl={config.hardcapBaseUrl}
  addressLookupBaseUrl={config.addressBaseUrl}
  getCurrentUser={() => auth.currentUser}
  getAuthToken={() => paymentAuth.getToken()}
  onSubmit={async (payload) => {
    const enriched = { ...payload, someExtraField: 'from GAB' };
    await submitMakerPayment(config.paymentApiBaseUrl, enriched, {
      getAuthToken: () => paymentAuth.getToken(),
    });
  }}
  onApprove={async (payload, comments) => { /* your call */ }}
  onReject={async (payload, comments) => { /* your call */ }}
  onResubmit={async (payload) => { /* your call */ }}
/>
```

## Verification pass (found and fixed one real bug)

Ran a structural cross-check across every file rather than just re-reading
and asserting correctness:

- Every property `PaymentParent.tsx` reads off `usePaymentParent`'s return
  value — confirmed present.
- Every field constructed in the `paymentInput` object — diffed exactly
  against `PaymentComponentInput`'s interface. Exact match, no missing or
  extra fields.
- Import resolution and brace/paren balance — checked across all 15 files.

**Found one real bug in this pass**: `fields`, `validationRules`, and
`onFormValid` — the dynamic-field-injection props we built — were never
actually forwarded through `PaymentParent`/`PaymentParentModal` down to
`SSPaymentFlow`. `PaymentParentProps` only extended `UsePaymentParentOptions`,
which doesn't include them, so there was no way for the consuming app to
actually pass custom fields in through the normal usage path. Fixed: these
three are now explicit fields on `PaymentParentProps`, destructured
separately from the hook options, and passed straight through to
`SSPaymentFlow`.
