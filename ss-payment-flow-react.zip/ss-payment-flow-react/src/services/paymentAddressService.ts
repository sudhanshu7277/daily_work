import { apiPost, ApiClientOptions } from './apiClient';

export interface AddressDetailsRequest {
  applicationName: string;
  applicationModule: string;
  countryCode: string;
  accountNumber: string;
  shortCode: string;
}

export interface AddressDetailsResponse {
  addressLine?: string[];
  addressLine1?: string;
  addressLine2?: string;
  streetName?: string;
  buildingNumber?: string;
  postalCode?: string;
  townName?: string;
  countryCode?: string;
  countrySubDivision?: string;
  state?: string;
}

/**
 * Converted from Angular PaymentAddressService (HttpClient -> fetch via apiClient).
 * Both lookups take baseUrl per-call, matching the original Angular service's signature.
 */
export async function lookupDebtorAddress(
  baseUrl: string,
  request: AddressDetailsRequest,
  options?: ApiClientOptions
): Promise<AddressDetailsResponse> {
  return apiPost<AddressDetailsResponse>(`${baseUrl}/debtor/address-lookup`, request, options);
}

export async function lookupCreditorAddress(
  baseUrl: string,
  request: AddressDetailsRequest,
  options?: ApiClientOptions
): Promise<AddressDetailsResponse> {
  return apiPost<AddressDetailsResponse>(`${baseUrl}/creditor/address-lookup`, request, options);
}
