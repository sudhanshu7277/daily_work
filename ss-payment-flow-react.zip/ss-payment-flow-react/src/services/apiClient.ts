/**
 * Shared HTTP client for all Java backend calls in this package.
 * Centralizes: auth header injection, JSON handling, and error message
 * extraction from typical Spring Boot error response shapes.
 *
 * NOTE: I'm assuming `Authorization: Bearer <token>` since that's the most
 * common pattern for Citi enterprise Java APIs behind a gateway, but this
 * needs confirming — if your backend expects a different header name
 * (X-Auth-Token, a cookie-based session, an API-gateway-specific header,
 * etc.), change buildHeaders() below accordingly.
 */

export interface ApiClientOptions {
  /**
   * Returns the current auth token for the PAYMENT backend specifically —
   * NOT necessarily the same token GAB uses for its own APIs (confirmed:
   * the payment Java backend does not accept GAB's own auth token). This is
   * async-capable because acquiring a separate credential for a different
   * backend often means its own call — a login, a client-credentials
   * exchange, a token-refresh endpoint — not just reading a value already
   * sitting in memory. Return null/undefined if no token is needed/available.
   */
  getAuthToken?: () => string | null | undefined | Promise<string | null | undefined>;
  /** Extra headers to send on every request (e.g. a static API key, X-App-Name, etc.) */
  extraHeaders?: Record<string, string>;
}

export class ApiError extends Error {
  status: number;
  body: unknown;

  constructor(message: string, status: number, body: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.body = body;
  }
}

async function buildHeaders(options?: ApiClientOptions): Promise<HeadersInit> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options?.extraHeaders ?? {}),
  };
  const token = await options?.getAuthToken?.();
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }
  return headers;
}

/**
 * Tries to pull a human-readable message out of common Spring Boot error
 * response shapes:
 *   - default Spring error body: { timestamp, status, error, message, path }
 *   - custom shapes seen in this app so far: { error: { error: string } },
 *     { message: string }
 * Falls back to the HTTP status text if nothing recognizable is found.
 */
async function extractErrorMessage(response: Response): Promise<{ message: string; body: unknown }> {
  let body: unknown = null;
  try {
    body = await response.json();
  } catch {
    // response wasn't JSON — fall through with body = null
  }

  if (body && typeof body === 'object') {
    const b = body as Record<string, unknown>;
    const nestedError = b.error;
    if (nestedError && typeof nestedError === 'object' && 'error' in (nestedError as object)) {
      const inner = (nestedError as Record<string, unknown>).error;
      if (typeof inner === 'string') return { message: inner, body };
    }
    if (typeof b.message === 'string') return { message: b.message, body };
    if (typeof b.error === 'string') return { message: b.error, body };
    if (typeof b.errorMessage === 'string') return { message: b.errorMessage, body };
  }

  return { message: `${response.status} ${response.statusText}`, body };
}

export async function apiPost<T>(
  url: string,
  payload: unknown,
  options?: ApiClientOptions
): Promise<T> {
  const response = await fetch(url, {
    method: 'POST',
    headers: await buildHeaders(options),
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const { message, body } = await extractErrorMessage(response);
    throw new ApiError(message, response.status, body);
  }

  return response.json() as Promise<T>;
}

export async function apiGet<T>(url: string, options?: ApiClientOptions): Promise<T> {
  const response = await fetch(url, {
    method: 'GET',
    headers: await buildHeaders(options),
  });

  if (!response.ok) {
    const { message, body } = await extractErrorMessage(response);
    throw new ApiError(message, response.status, body);
  }

  return response.json() as Promise<T>;
}
