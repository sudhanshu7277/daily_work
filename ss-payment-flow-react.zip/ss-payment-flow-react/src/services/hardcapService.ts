import { VerifyHardCapRequest, VerifyHardCapResponse } from '../models/hardcap.model';
import { apiPost, ApiClientOptions } from './apiClient';

/**
 * Verifies whether a payment amount is within the configured hard cap limit.
 * Converted from Angular HardcapService (HttpClient -> fetch via apiClient).
 *
 * @param baseUrl base URL for the hard-cap check API (was `environment.apiUrl` in Angular;
 *                in React this is supplied via PaymentComponentInput.hardcapLimitCheckBaseUrl)
 * @param request the verification payload
 * @param options auth token / extra headers for the shared API client
 */
export async function verifyHardCap(
  baseUrl: string,
  request: VerifyHardCapRequest,
  options?: ApiClientOptions
): Promise<VerifyHardCapResponse> {
  return apiPost<VerifyHardCapResponse>(`${baseUrl}/hard-cap/verify`, request, options);
}
