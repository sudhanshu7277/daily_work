import {
  Pain001ValidationRules,
  FieldValidationResult,
  ValidationEffect,
  ValidationCondition,
} from '../models/validationRule.model';

/**
 * Converted from Angular GenericValidatorService.
 *
 * The rule-evaluation logic (evaluateAllFields, evaluateFieldRules, evaluateFormRules,
 * mergeEffects, mergeResultsWithFormEffects, allConditionsMatch, conditionMatches,
 * isValueEmpty, extractCountryFromBIC, effectToResult) is pure TypeScript and ports
 * over unchanged.
 *
 * What changed: Angular's `buildValidators` + `applyToForm` mutated a FormGroup's
 * ValidatorFn[] directly. React has no FormGroup, so those two are replaced with:
 *   - `validateFieldValue(value, result)` — checks one value against a FieldValidationResult
 *     and returns an error message (or null), for use in an onChange/onBlur handler.
 *   - `applyToFields(formValues, fieldResults, formRuleEffects)` — same merge behavior as
 *     `applyToForm`, minus the FormGroup mutation. Returns the merged
 *     Map<fieldName, FieldValidationResult> for the caller to store in React state.
 */
export class GenericValidatorService {
  private readonly rules: Pain001ValidationRules;

  constructor(rules: Pain001ValidationRules) {
    this.rules = rules;
  }

  getRules(): Pain001ValidationRules {
    return this.rules;
  }

  extractCountryFromBIC(bic: string): string {
    if (!bic || bic.length < 6) {
      return '';
    }
    return bic.substring(4, 6).toUpperCase();
  }

  evaluateAllFields(formValues: Record<string, unknown>): Map<string, FieldValidationResult> {
    const results = new Map<string, FieldValidationResult>();

    for (const fieldName of Object.keys(this.rules.fields)) {
      const result = this.evaluateFieldRules(fieldName, formValues);
      results.set(fieldName, result);
    }

    return results;
  }

  evaluateFieldRules(fieldName: string, formValues: Record<string, unknown>): FieldValidationResult {
    const rules = this.rules.fields[fieldName];
    const defaultResult: FieldValidationResult = {
      fieldName,
      required: false,
      visible: true,
    };

    if (!rules || rules.length === 0) {
      return defaultResult;
    }

    const sorted = [...rules].sort((a, b) => a.priority - b.priority);

    for (const rule of sorted) {
      if (this.allConditionsMatch(rule.conditions, formValues)) {
        return this.effectToResult(fieldName, rule.effect);
      }
    }

    return defaultResult;
  }

  evaluateFormRules(formValues: Record<string, unknown>): Map<string, ValidationEffect> {
    const effects = new Map<string, ValidationEffect>();

    for (const rule of this.rules.formRules) {
      if (this.allConditionsMatch(rule.conditions, formValues)) {
        for (const [fieldName, effect] of Object.entries(rule.effects)) {
          const existing = effects.get(fieldName);
          if (existing) {
            effects.set(fieldName, this.mergeEffects(existing, effect));
          } else {
            effects.set(fieldName, { ...effect });
          }
        }
      }
    }

    return effects;
  }

  /**
   * Angular original: buildValidators(result) -> ValidatorFn[]
   * React equivalent: validate a single value directly and return an error message.
   */
  validateFieldValue(value: unknown, result: FieldValidationResult): string | null {
    if (result.required && this.isValueEmpty(value)) {
      return 'This field is required';
    }

    if (result.pattern) {
      const regex = new RegExp(result.pattern);
      if (!this.isValueEmpty(value) && !regex.test(String(value))) {
        return result.patternMessage || 'Invalid format';
      }
    }

    if (result.maxLength !== undefined && result.maxLength > 0) {
      if (!this.isValueEmpty(value) && String(value).length > result.maxLength) {
        return `Maximum length is ${result.maxLength}`;
      }
    }

    return null;
  }

  /**
   * Angular original: applyToForm(form, fieldResults, formRuleEffects) mutated each
   * FormControl's validators. React equivalent: return the merged results only —
   * the caller stores this Map in state and calls validateFieldValue per-field
   * (e.g. on change/blur, or all at once on submit).
   */
  applyToFields(
    fieldResults: Map<string, FieldValidationResult>,
    formRuleEffects: Map<string, ValidationEffect>
  ): Map<string, FieldValidationResult> {
    return this.mergeResultsWithFormEffects(fieldResults, formRuleEffects);
  }

  private allConditionsMatch(conditions: ValidationCondition[], formValues: Record<string, unknown>): boolean {
    if (!conditions || conditions.length === 0) {
      return true;
    }
    return conditions.every(c => this.conditionMatches(c, formValues));
  }

  private isValueEmpty(v: unknown): boolean {
    return v === null || v === undefined || String(v as string).trim() === '';
  }

  private conditionMatches(condition: ValidationCondition, formValues: Record<string, unknown>): boolean {
    const sourceFields = condition.sourceField.split(',');

    if (sourceFields.length > 1) {
      if (condition.operator === 'notEmpty') {
        return sourceFields.some(f => !this.isValueEmpty(formValues[f.trim()]));
      }
      if (condition.operator === 'empty') {
        return sourceFields.every(f => this.isValueEmpty(formValues[f.trim()]));
      }
    }

    const rawValue = formValues[sourceFields[0].trim()];
    let compareValue = this.isValueEmpty(rawValue) ? '' : String(rawValue as string).trim();

    if (condition.derivation === 'bicCountry') {
      compareValue = this.extractCountryFromBIC(compareValue);
    }

    switch (condition.operator) {
      case 'eq':
        return compareValue === condition.value;
      case 'neq':
        return compareValue !== condition.value;
      case 'in':
        return Array.isArray(condition.value) && condition.value.includes(compareValue);
      case 'notIn':
        return Array.isArray(condition.value) && !condition.value.includes(compareValue);
      case 'empty':
        return compareValue === '';
      case 'notEmpty':
        return compareValue !== '';
      default:
        return false;
    }
  }

  private effectToResult(fieldName: string, effect: ValidationEffect): FieldValidationResult {
    return {
      fieldName,
      required: effect.required ?? false,
      visible: effect.visible ?? true,
      pattern: effect.pattern,
      patternMessage: effect.patternMessage,
      maxLength: effect.maxLength,
      decimalPlaces: effect.decimalPlaces,
    };
  }

  private mergeEffects(base: ValidationEffect, override: ValidationEffect): ValidationEffect {
    return {
      required: override.required ?? base.required,
      visible: override.visible ?? base.visible,
      pattern: override.pattern ?? base.pattern,
      patternMessage: override.patternMessage ?? base.patternMessage,
      maxLength: override.maxLength ?? base.maxLength,
      decimalPlaces: override.decimalPlaces ?? base.decimalPlaces,
    };
  }

  private mergeResultsWithFormEffects(
    fieldResults: Map<string, FieldValidationResult>,
    formRuleEffects: Map<string, ValidationEffect>
  ): Map<string, FieldValidationResult> {
    const merged = new Map<string, FieldValidationResult>(fieldResults);

    for (const [fieldName, effect] of formRuleEffects) {
      const existing = merged.get(fieldName);
      if (existing) {
        const mergedEffect = this.mergeEffects(existing, effect);
        merged.set(fieldName, { ...existing, ...mergedEffect });
      } else {
        merged.set(fieldName, this.effectToResult(fieldName, effect));
      }
    }

    return merged;
  }
}
