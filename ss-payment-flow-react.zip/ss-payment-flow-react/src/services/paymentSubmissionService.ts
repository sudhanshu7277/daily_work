import { apiPost, ApiClientOptions } from './apiClient';

export interface PaymentSubmissionResponse {
  referenceId: string;
  status: string;
  message: string;
}

/**
 * Converted from PaymentParentComponent.submitPaymentToBackend (this.http.post -> apiClient).
 * apiBaseUrl replaces Angular's `environment.apiUrl`.
 */
export async function submitMakerPayment(
  apiBaseUrl: string,
  payload: Record<string, unknown>,
  options?: ApiClientOptions
): Promise<PaymentSubmissionResponse> {
  return apiPost<PaymentSubmissionResponse>(`${apiBaseUrl}/api/payments/createMakerPayment`, payload, options);
}

/**
 * Converted from PaymentParentComponent.onApprove (this.http.post -> apiClient).
 */
export async function submitCheckerApproval(
  apiBaseUrl: string,
  payload: Record<string, unknown>,
  options?: ApiClientOptions
): Promise<PaymentSubmissionResponse & { status: string }> {
  return apiPost(`${apiBaseUrl}/api/payments/checker/approve`, payload, options);
}
