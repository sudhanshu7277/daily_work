import React, { useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PaymentParent, PaymentParentProps } from './PaymentParent';

export interface PaymentParentModalProps extends PaymentParentProps {
  /** Where to navigate when the modal closes. Defaults to navigate(-1). */
  closeTo?: string;
  title?: string;
}

/**
 * Route-triggered modal wrapper for PaymentParent.
 *
 * This is now a PURE SHELL — backdrop, header, close behavior. All button
 * logic (Submit/Approve/Reject/Resubmit/Cancel) lives in PaymentParent
 * itself, matching the real Angular parent template's structure. The
 * `onCancel` prop you pass through here is wired to also close the modal,
 * in addition to whatever else you want it to do.
 *
 * Usage:
 *   <Route path="/payments/new" element={
 *     <PaymentParentModal
 *       hardcapLimitCheckBaseUrl={config.hardcapBaseUrl}
 *       addressLookupBaseUrl={config.addressBaseUrl}
 *       getCurrentUser={() => auth.currentUser}
 *       getAuthToken={() => paymentAuth.getToken()}
 *       onSubmit={async (payload) => {
 *         // you decide: call submitMakerPayment as-is, append more data first, etc.
 *         await submitMakerPayment(config.paymentApiBaseUrl, payload, { getAuthToken: () => paymentAuth.getToken() });
 *       }}
 *     />
 *   } />
 */
export function PaymentParentModal(props: PaymentParentModalProps) {
  const { closeTo, title = 'Payment', onCancel, ...paymentParentProps } = props;
  const navigate = useNavigate();

  const close = useCallback(() => {
    if (closeTo) {
      navigate(closeTo);
    } else {
      navigate(-1);
    }
  }, [navigate, closeTo]);

  const handleCancel = useCallback(() => {
    onCancel?.();
    close();
  }, [onCancel, close]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        close();
      }
    };
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [close]);

  return (
    <div id="myModal" className="modal">
      <div className="modal-backdrop" onClick={close}>
        <div className="modal-container" onClick={e => e.stopPropagation()}>
          <header className="modal-header">
            <h1>{title}</h1>
            <button className="close-btn" aria-label="Close" onClick={close}>
              &times;
            </button>
          </header>

          <div className="modal-body">
            <PaymentParent {...paymentParentProps} onCancel={handleCancel} />
          </div>
        </div>
      </div>
    </div>
  );
}
