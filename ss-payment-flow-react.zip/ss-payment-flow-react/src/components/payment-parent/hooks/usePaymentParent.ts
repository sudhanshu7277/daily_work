import { useCallback, useMemo, useState } from 'react';
import {
  PaymentMode,
  DualBlindKeyFlag,
  PaymentComponentInput,
  PaymentComponentOutput,
} from '../../../models/paymentComponent.model';
import { Pain001Model } from '../../../models/pain001.model';
import { verifyHardCap } from '../../../services/hardcapService';
import { pacsFormVerbiages, appFieldConfig } from '../../../config/paymentParentConfig';

/**
 * Ported from PaymentParentComponent.paymentDetailsRequest.
 * NOTE: the Angular source maps `paymentData.creditorAgentPostalAddress` in
 * payloadPreperation, but Pain001Model has no such field — only
 * `creditorAgentAccountNumber`. Mapped to the latter below; flag if that's wrong.
 */
export interface PaymentDetailsRequest {
  requestedExecutionDate: string;
  source: string;
  debtorName: string;
  debtorAccountNumber: string;
  debtorAgentBIC: string;
  chargeBearer: string;
  chargesAmount: number;
  chargesAgentBIC: string;
  debtorAddressLines: string;
  debtorStreetName: string;
  debtorBuildingNumber: string;
  debtorPostalCode: string;
  debtorTownName: string;
  debtorCountrySubDivision: string;
  debtorCountryCode: string;
  debtorSortCodeUK: string;
  debtorSortCodeUS: string;
  instructedAmount: number;
  instructedAmountCurrencyCode: string;
  creditorName: string;
  creditorAccount: string;
  creditorAgentFinancialInstitutionBIC: string;
  creditorAgentFinancialInstitutionName: string;
  creditorAgentAccountNumber: string;
  creditorAddressLines: string;
  creditorStreetName: string;
  creditorBuildingNumber: string;
  creditorPostalCode: string;
  creditorTownName: string;
  creditorCountrySubDivision: string;
  creditorCountryCode: string;
  creditorSortCodeUK: string;
  creditorSortCodeUS: string;
  ustrdPaymentDetails: string;
  painPaymentMethodType: string;
  firstIntermediaryBankBIC: string;
  firstIntermediaryBankRoutingCode: string;
  firstIntermediaryBankName: string;
  firstIntermediaryBankCountryCode: string;
  firstIntermediaryBankAccountId: string;
  secondIntermediaryBankBIC: string;
  secondIntermediaryBankRoutingCode: string;
  secondIntermediaryBankName: string;
  secondIntermediaryBankCountryCode: string;
  secondIntermediaryBankAccountId: string;
  applicationName: string;
  applicationModule: string;
  region: string;
}

const createDefaultPaymentDetailsRequest = (): PaymentDetailsRequest => ({
  requestedExecutionDate: '',
  source: '',
  debtorName: '',
  debtorAccountNumber: '',
  debtorAgentBIC: '',
  chargeBearer: '',
  chargesAmount: 0,
  chargesAgentBIC: '',
  debtorAddressLines: '',
  debtorStreetName: '',
  debtorBuildingNumber: '',
  debtorPostalCode: '',
  debtorTownName: '',
  debtorCountrySubDivision: '',
  debtorCountryCode: '',
  debtorSortCodeUK: '',
  debtorSortCodeUS: '',
  instructedAmount: 0,
  instructedAmountCurrencyCode: '',
  creditorName: '',
  creditorAccount: '',
  creditorAgentFinancialInstitutionBIC: '',
  creditorAgentFinancialInstitutionName: '',
  creditorAgentAccountNumber: '',
  creditorAddressLines: '',
  creditorStreetName: '',
  creditorBuildingNumber: '',
  creditorPostalCode: '',
  creditorTownName: '',
  creditorCountrySubDivision: '',
  creditorCountryCode: '',
  creditorSortCodeUK: '',
  creditorSortCodeUS: '',
  ustrdPaymentDetails: '',
  painPaymentMethodType: '',
  firstIntermediaryBankBIC: '',
  firstIntermediaryBankRoutingCode: '',
  firstIntermediaryBankName: '',
  firstIntermediaryBankCountryCode: '',
  firstIntermediaryBankAccountId: '',
  secondIntermediaryBankBIC: '',
  secondIntermediaryBankRoutingCode: '',
  secondIntermediaryBankName: '',
  secondIntermediaryBankCountryCode: '',
  secondIntermediaryBankAccountId: '',
  applicationName: 'ADR',
  applicationModule: 'ADR',
  region: '',
});

const DEFAULT_DUAL_BLIND_KEY_FIELDS_INPUT =
  'instructedAmount,creditorName,debtorName,debtorAccountNumber,debtorAgentBIC,instructedAmountCurrencyCode' +
  ',creditorName,creditorAccount,creditorAgentFinancialInstitutionBIC,creditorAgentFinancialInstitutionName,creditorAgentPostalAddress';

interface CheckerData {
  eventRecordDate: string;
  issCode: string;
  eventType: string;
  securityId: string;
}

export interface UsePaymentParentOptions {
  hardcapLimitCheckBaseUrl?: string;
  addressLookupBaseUrl?: string;
  makerSubmitUrl?: string;
  getCurrentUser: () => { name?: string } | null;
  getAuthToken?: () => string | null | undefined | Promise<string | null | undefined>;

  /**
   * ARCHITECTURE NOTE: this hook does NOT call any submit/approve/reject
   * API itself anymore. It only builds the payload and hands it to you via
   * these callbacks — you decide whether to call the still-exported
   * services/paymentSubmissionService.ts functions as-is, append more data
   * first, route it somewhere else entirely, etc. If your callback returns
   * a Promise, `isProcessing` reflects it while it's pending.
   */
  onSubmit?: (payload: PaymentDetailsRequest) => void | Promise<void>;
  onApprove?: (payload: PaymentDetailsRequest, comments: string) => void | Promise<void>;
  onReject?: (payload: PaymentDetailsRequest, comments: string) => void | Promise<void>;
  onResubmit?: (payload: PaymentDetailsRequest) => void | Promise<void>;
  onCancel?: () => void;
}

/** Ported from PaymentParentComponent.parseCommaSeparated */
function parseCommaSeparated(input: string): string[] {
  if (!input || !input.trim()) {
    return [];
  }
  return input.split(',').map(s => s.trim()).filter(s => s.length > 0);
}

export function usePaymentParent(options: UsePaymentParentOptions) {
  const { getCurrentUser, getAuthToken, onSubmit, onApprove, onReject, onResubmit, onCancel } = options;

  const [selectedMode, setSelectedMode] = useState<PaymentMode>('maker');
  const [dualBlindKeyFlag, setDualBlindKeyFlag] = useState<DualBlindKeyFlag>('N');
  const [currency, setCurrency] = useState('USD');
  const [comments, setComments] = useState('');
  const [isDualBlindKeyPassed, setIsDualBlindKeyPassed] = useState(false);

  const [hardcapBaseUrl] = useState(options.hardcapLimitCheckBaseUrl ?? '');
  const [hideFieldsInput, setHideFieldsInput] = useState('');
  const [dualBlindKeyFieldsInput, setDualBlindKeyFieldsInput] = useState(DEFAULT_DUAL_BLIND_KEY_FIELDS_INPUT);
  const [rejectedFieldsInput, setRejectedFieldsInput] = useState('');

  const [lastOutput, setLastOutput] = useState<PaymentComponentOutput | null>(null);
  const [enableSubmitButton, setEnableSubmitButton] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const [currentPaymentModel, setCurrentPaymentModel] = useState<Pain001Model | null>(null);
  const [checkerData, setCheckerData] = useState<CheckerData>({
    eventRecordDate: '',
    issCode: '',
    eventType: '',
    securityId: '',
  });
  const [captureAuthorizationResponse, setCaptureAuthorizationResponse] = useState<any>(null);
  const [parentDetailsFormValues, setParentDetailsFormValues] = useState<
    Record<string, string | number | boolean>
  >({});

  const [isMakerMode] = useState<'Maker' | 'Checker'>('Maker');
  const [hardcapValidating, setHardcapValidating] = useState(true);
  const [hardcapError, setHardcapError] = useState('');
  const [hardcapResult, setHardcapResult] = useState<{ amountWithinLimit: boolean; hardCapValue: number } | null>(
    null
  );
  const [hardcapSuccessMessage, setHardcapSuccessMessage] = useState('');
  const [hardcapAmountObjectReceivedFromChild, setHardcapAmountObjectReceivedFromChild] = useState<{
    instructedAmount: string | number;
    instructedAmountCurrencyCode: string;
  }>({ instructedAmount: '', instructedAmountCurrencyCode: '' });

  const [paymentDetailsRequest, setPaymentDetailsRequest] = useState<PaymentDetailsRequest>(
    createDefaultPaymentDetailsRequest()
  );

  /** Ported from PaymentParentComponent get paymentInput() */
  const paymentInput: PaymentComponentInput = useMemo(
    () => ({
      applicationName: 'ADR',
      applicationModule: 'ADR',
      hideFieldsList: parseCommaSeparated(hideFieldsInput),
      currency,
      dualBlindKeyFields: parseCommaSeparated(dualBlindKeyFieldsInput),
      dualBlindKeyFlag,
      paymentModel: currentPaymentModel,
      rejectedFieldList: parseCommaSeparated(rejectedFieldsInput),
      paymentMode: selectedMode,
      hardcapLimitCheckBaseUrl: hardcapBaseUrl,
      addressLookupBaseUrl: options.addressLookupBaseUrl ?? hardcapBaseUrl,
      makerSubmitUrl: options.makerSubmitUrl ?? '',
      region: '',
      useMockApi: false,
    }),
    [
      hideFieldsInput,
      currency,
      dualBlindKeyFieldsInput,
      dualBlindKeyFlag,
      currentPaymentModel,
      rejectedFieldsInput,
      selectedMode,
      hardcapBaseUrl,
      options.addressLookupBaseUrl,
      options.makerSubmitUrl,
    ]
  );

  /** Ported from PaymentParentComponent.payloadPreperation */
  const payloadPreperation = useCallback((paymentData: Pain001Model) => {
    setPaymentDetailsRequest(prev => ({
      ...prev,
      requestedExecutionDate: paymentData.requestedExecutionDate,
      source: '',
      debtorName: paymentData.debtorName,
      debtorAccountNumber: paymentData.debtorAccountNumber,
      debtorAgentBIC: paymentData.debtorAgentBIC,
      chargeBearer: paymentData.chargeBearer ?? '',
      chargesAmount: paymentData.chargesAmount ?? 0,
      chargesAgentBIC: paymentData.chargesAgentBIC ?? '',
      debtorAddressLines: paymentData.debtorAddressLines ?? '',
      debtorStreetName: paymentData.debtorStreetName ?? '',
      debtorBuildingNumber: paymentData.debtorBuildingNumber ?? '',
      debtorPostalCode: paymentData.debtorPostalCode ?? '',
      debtorTownName: paymentData.debtorTownName ?? '',
      debtorCountrySubDivision: paymentData.debtorCountrySubDivision ?? '',
      debtorCountryCode: paymentData.debtorCountryCode ?? '',
      debtorSortCodeUK: paymentData.debtorSortCodeUK ?? '',
      debtorSortCodeUS: paymentData.debtorSortCodeUS ?? '',
      instructedAmount: paymentData.instructedAmount,
      instructedAmountCurrencyCode: paymentData.instructedAmountCurrencyCode,
      creditorName: paymentData.creditorName,
      creditorAccount: paymentData.creditorAccount,
      creditorAgentFinancialInstitutionBIC: paymentData.creditorAgentFinancialInstitutionBIC,
      creditorAgentFinancialInstitutionName: paymentData.creditorAgentFinancialInstitutionName,
      creditorAgentAccountNumber: paymentData.creditorAgentAccountNumber ?? '',
      creditorAddressLines: paymentData.creditorAddressLines ?? '',
      creditorStreetName: paymentData.creditorStreetName ?? '',
      creditorBuildingNumber: paymentData.creditorBuildingNumber ?? '',
      creditorPostalCode: paymentData.creditorPostalCode ?? '',
      creditorTownName: paymentData.creditorTownName ?? '',
      creditorCountrySubDivision: paymentData.creditorCountrySubDivision ?? '',
      creditorCountryCode: paymentData.creditorCountryCode ?? '',
      creditorSortCodeUK: paymentData.creditorSortCodeUK ?? '',
      creditorSortCodeUS: paymentData.creditorSortCodeUS ?? '',
      ustrdPaymentDetails: paymentData.ustrdPaymentDetails ?? '',
      painPaymentMethodType: paymentData.painPaymentMethodType,
      firstIntermediaryBankBIC: paymentData.firstIntermediaryBankBIC ?? '',
      firstIntermediaryBankRoutingCode: paymentData.firstIntermediaryBankRoutingCode ?? '',
      firstIntermediaryBankName: paymentData.firstIntermediaryBankName ?? '',
      firstIntermediaryBankCountryCode: paymentData.firstIntermediaryBankCountryCode ?? '',
      firstIntermediaryBankAccountId: paymentData.firstIntermediaryBankAccountId ?? '',
      secondIntermediaryBankBIC: paymentData.secondIntermediaryBankBIC ?? '',
      secondIntermediaryBankRoutingCode: paymentData.secondIntermediaryBankRoutingCode ?? '',
      secondIntermediaryBankName: paymentData.secondIntermediaryBankName ?? '',
      secondIntermediaryBankCountryCode: paymentData.secondIntermediaryBankCountryCode ?? '',
      secondIntermediaryBankAccountId: paymentData.secondIntermediaryBankAccountId ?? '',
      applicationName: paymentData.applicationName || 'ADR',
      applicationModule: paymentData.applicationModule || 'ADR',
      region: paymentData.region ?? '',
    }));
  }, []);

  /**
   * Ported from PaymentParentComponent.validateHardcap (body reconstructed —
   * tail of source was cut off). This is a SEPARATE, parent-level hardcap
   * check independent of the one SSPaymentFlow does internally on amount
   * blur — matches documented behavior of the real component having "the
   * parent's own independent validateHardcap." Still a live in-form check,
   * unrelated to final submission.
   */
  const validateHardcap = useCallback(
    async (hardCapPayload: { instructedAmount: string | number; instructedAmountCurrencyCode: string }) => {
      if (isMakerMode !== 'Maker') {
        return;
      }
      setHardcapValidating(true);
      setHardcapError('');
      try {
        const result = await verifyHardCap(
          hardcapBaseUrl,
          {
            currency: hardCapPayload.instructedAmountCurrencyCode,
            paymentAmount: Number(hardCapPayload.instructedAmount),
            applicationName: 'ADR',
            applicationModule: 'ADR',
          },
          { getAuthToken }
        );
        setHardcapResult(result);
        setHardcapSuccessMessage(result.amountWithinLimit ? 'Amount is within hard cap limit' : '');
        if (!result.amountWithinLimit) {
          setHardcapError(`Amount exceeds hard cap limit of ${result.hardCapValue}`);
        }
      } catch (err) {
        setHardcapError('Unable to validate hard cap limit');
      } finally {
        setHardcapValidating(false);
      }
    },
    [isMakerMode, hardcapBaseUrl, getAuthToken]
  );

  const onAmountChange = useCallback(
    (hardCapPayloadFromMakerChild: { instructedAmount: string | number; instructedAmountCurrencyCode: string }) => {
      setHardcapAmountObjectReceivedFromChild(hardCapPayloadFromMakerChild);
      if (hardCapPayloadFromMakerChild.instructedAmount) {
        void validateHardcap(hardCapPayloadFromMakerChild);
      }
    },
    [validateHardcap]
  );

  const onPaymentOutput = useCallback(
    (output: PaymentComponentOutput) => {
      payloadPreperation(output.paymentData);
      setEnableSubmitButton(output.isValid);
      setLastOutput(output);
      setIsDualBlindKeyPassed(output.isDualBlindKeyPassed);
    },
    [payloadPreperation]
  );

  // ── Button actions — each just builds/hands off the payload. No fetch
  // calls live here anymore; onSubmit/onApprove/onReject/onResubmit are
  // supplied by whoever renders PaymentParent (the consuming app), and
  // that's who decides what actually happens with the payload. ──────────

  const submit = useCallback(async () => {
    if (!onSubmit) return;
    setIsProcessing(true);
    try {
      await onSubmit(paymentDetailsRequest);
    } finally {
      setIsProcessing(false);
    }
  }, [onSubmit, paymentDetailsRequest]);

  const approve = useCallback(async () => {
    if (!onApprove) return;
    setIsProcessing(true);
    try {
      await onApprove(paymentDetailsRequest, comments);
    } finally {
      setIsProcessing(false);
    }
  }, [onApprove, paymentDetailsRequest, comments]);

  const reject = useCallback(async () => {
    if (!onReject) return;
    setIsProcessing(true);
    try {
      await onReject(paymentDetailsRequest, comments);
    } finally {
      setIsProcessing(false);
    }
  }, [onReject, paymentDetailsRequest, comments]);

  const resubmit = useCallback(async () => {
    if (!onResubmit) return;
    setIsProcessing(true);
    try {
      await onResubmit(paymentDetailsRequest);
    } finally {
      setIsProcessing(false);
    }
  }, [onResubmit, paymentDetailsRequest]);

  const cancel = useCallback(() => {
    onCancel?.();
  }, [onCancel]);

  /**
   * Replaces the Angular ngOnInit DataSharingService.checkerData subscription.
   * Call this from the host page when checker data becomes available.
   * NOTE: depends on buildPain001ModelFromDetails / populatePaymentDetailsFromSource,
   * which weren't captured in these screenshots — pass them in until ported.
   */
  const applyCheckerMessage = useCallback(
    (
      message: any,
      utils: {
        buildPain001ModelFromDetails: (details: any) => Pain001Model;
        populatePaymentDetailsFromSource: (target: PaymentDetailsRequest, source: any) => PaymentDetailsRequest;
        formatDateForInput: (date: string | undefined) => string;
      }
    ) => {
      if (!message || !message.txnId) {
        return;
      }
      setCaptureAuthorizationResponse(message);
      setDualBlindKeyFlag(message.paymentTransactionWorkflow?.isDualBlindKeyChecker1 ?? 'N');

      setCheckerData({
        securityId: message.securityId || '',
        eventRecordDate: utils.formatDateForInput(message.eventRecordDate) || '',
        eventType: message.eventType || '',
        issCode: message.issCode || '',
      });

      if (message.paymentDetailsRequest) {
        setCurrentPaymentModel(utils.buildPain001ModelFromDetails(message.paymentDetailsRequest));
        setPaymentDetailsRequest(prev => utils.populatePaymentDetailsFromSource(prev, message.paymentDetailsRequest));
      }
    },
    []
  );

  const loadRepairSample = useCallback(
    (loadCheckerSample: any, utils: { buildPain001ModelFromDetails: (details: any) => Pain001Model }) => {
      setCurrentPaymentModel(utils.buildPain001ModelFromDetails(loadCheckerSample));
      setSelectedMode('repair');
      setRejectedFieldsInput('debtorName,creditorName,instructedAmount');
    },
    []
  );

  const clearPaymentModel = useCallback(() => {
    setCurrentPaymentModel(null);
  }, []);

  return {
    selectedMode,
    setSelectedMode,
    dualBlindKeyFlag,
    currency,
    setCurrency,
    comments,
    setComments,
    isDualBlindKeyPassed,
    hideFieldsInput,
    setHideFieldsInput,
    dualBlindKeyFieldsInput,
    setDualBlindKeyFieldsInput,
    rejectedFieldsInput,
    setRejectedFieldsInput,
    lastOutput,
    enableSubmitButton,
    isProcessing,
    currentPaymentModel,
    checkerData,
    captureAuthorizationResponse,
    paymentDetailsRequest,
    hardcapValidating,
    hardcapError,
    hardcapResult,
    hardcapSuccessMessage,
    hardcapAmountObjectReceivedFromChild,
    parentDetailsFormValues,
    setParentDetailsFormValues,
    paymentInput,
    fieldConfig: appFieldConfig,
    pacsFormVerbiages,
    getAuthToken,
    onPaymentOutput,
    onAmountChange,
    submit,
    approve,
    reject,
    resubmit,
    cancel,
    applyCheckerMessage,
    loadRepairSample,
    clearPaymentModel,
  };
}
