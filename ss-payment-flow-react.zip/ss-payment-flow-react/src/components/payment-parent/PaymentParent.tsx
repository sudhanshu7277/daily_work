import React from 'react';
import { usePaymentParent, UsePaymentParentOptions } from './hooks/usePaymentParent';
import { SSPaymentFlow, DynamicFieldDefinition } from '../ss-payment-flow/SSPaymentFlow';
import { Pain001Model } from '../../models/pain001.model';
import { Pain001ValidationRules } from '../../models/validationRule.model';

export interface PaymentParentProps extends UsePaymentParentOptions {
  /** Forwarded straight through to SSPaymentFlow — see DynamicFieldDefinition for shape. Omit to use the default full payment field set. */
  fields?: DynamicFieldDefinition[];
  /** Forwarded straight through to SSPaymentFlow. */
  validationRules?: Pain001ValidationRules;
  /** Forwarded straight through to SSPaymentFlow — fires once when the form becomes valid. */
  onFormValid?: (data: Pain001Model) => void;
}

/**
 * Converted from payment-parent.component.html/.ts.
 *
 * Differences from the Angular source:
 * - `<ss-payment-flow>` (Angular Elements custom element) is replaced with
 *   the React `SSPaymentFlow` component directly — no custom-element bridge needed.
 * - Submit/Reject/Approve/Resubmit/Cancel buttons ARE rendered here (all
 *   three modes), matching the real Angular parent template, but they do
 *   NOT call any API directly. Each button calls the matching onSubmit /
 *   onApprove / onReject / onResubmit / onCancel prop you supply — this
 *   component only builds the payload and hands it off. What happens next
 *   (call an endpoint as-is, append more data first, do something else
 *   entirely) is entirely up to whatever renders PaymentParent.
 * - No built-in success/failure modal. That was previously driven by this
 *   component's own fetch responses; since it no longer makes those calls,
 *   showing a result is now the consuming app's responsibility (e.g. based
 *   on what your onSubmit/onApprove/onReject promise resolves or rejects with).
 */
export function PaymentParent(props: PaymentParentProps) {
  const { fields, validationRules, onFormValid, ...hookOptions } = props;
  const p = usePaymentParent(hookOptions);

  return (
    <div className="payment-component-wrapper">
      <SSPaymentFlow
        paymentInput={p.paymentInput}
        fieldConfig={p.fieldConfig}
        fields={fields}
        validationRules={validationRules}
        onPaymentOutput={p.onPaymentOutput}
        onFormValid={onFormValid}
        onAmountChange={p.onAmountChange}
        getAuthToken={p.getAuthToken}
      />

      {p.selectedMode === 'maker' && (
        <div className="action-bar">
          <button type="button" className="lmn-btn" onClick={p.cancel} disabled={p.isProcessing}>
            Cancel
          </button>
          <button
            type="button"
            className="lmn-btn lmn-btn-primary"
            onClick={p.submit}
            disabled={!p.enableSubmitButton || p.isProcessing}
          >
            {p.pacsFormVerbiages.SubmitPayment ?? 'Submit Payment'}
          </button>
        </div>
      )}

      {p.selectedMode === 'checker' && (
        <div className="action-container">
          <div className="form-group">
            <label htmlFor="checkerComments">Comments (Optional)</label>
            <textarea
              id="checkerComments"
              className="lmn-form-control"
              rows={3}
              placeholder="Enter any additional comments"
              value={p.comments}
              onChange={e => p.setComments(e.target.value)}
            />
          </div>
          <div className="action-bar">
            <button type="button" className="lmn-btn" onClick={p.cancel} disabled={p.isProcessing}>
              Cancel
            </button>
            <button type="button" className="btn-reject" onClick={p.reject} disabled={p.isProcessing}>
              Reject
            </button>
            <button
              type="button"
              className="btn-approve"
              onClick={p.approve}
              disabled={p.isProcessing || (!p.isDualBlindKeyPassed && p.dualBlindKeyFlag === 'Y')}
            >
              Approve
            </button>
          </div>
        </div>
      )}

      {p.selectedMode === 'repair' && (
        <div className="action-bar">
          <button type="button" className="lmn-btn" onClick={p.cancel} disabled={p.isProcessing}>
            Cancel
          </button>
          <button
            type="button"
            className="lmn-btn lmn-btn-primary"
            onClick={p.resubmit}
            disabled={!p.enableSubmitButton || p.isProcessing}
          >
            Resubmit Payment
          </button>
        </div>
      )}
    </div>
  );
}
