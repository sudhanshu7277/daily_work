import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Pain001Model,
  createEmptyPain001,
  FormFieldConfig,
  DEFAULT_FIELD_CONFIG,
  ALWAYS_REQUIRED_FIELDS,
  PAIN001_FIELD_DEFINITIONS,
  CHARGE_BEARER_OPTIONS,
  PAYMENT_METHOD_OPTIONS,
  SelectOption,
} from '../../models/pain001.model';
import { PaymentComponentInput, PaymentComponentOutput } from '../../models/paymentComponent.model';
import { Pain001ValidationRules } from '../../models/validationRule.model';
import { GenericValidatorService } from '../../services/genericValidator';
import { verifyHardCap } from '../../services/hardcapService';
import { lookupDebtorAddress, lookupCreditorAddress } from '../../services/paymentAddressService';
import './PaymentFlow.scss';

export type FieldInputType = 'text' | 'number' | 'date' | 'select' | 'textarea';

/**
 * A single field's render definition — name, label, TYPE, section, and
 * (for selects) options are all driven by this, not hardcoded per-field
 * JSX. Pass your own array via the `fields` prop to control exactly which
 * fields render, in what order, under what section headings, and as what
 * input type. Defaults to DEFAULT_PAYMENT_FIELDS if omitted.
 *
 * NOTE on scope: `name` is typed to `keyof Pain001Model` because the
 * underlying form data is still a typed Pain001Model — this dynamically
 * controls WHICH fields render, AS WHAT TYPE, and HOW THEY'RE GROUPED, but
 * doesn't support inventing entirely new field names outside the payment
 * data model. If you need fields with no relationship to Pain001Model at
 * all, that's a different, larger change (formValues would need to become
 * a fully generic Record<string, unknown> instead) — flag if that's
 * actually what's needed and I'll rebuild for that instead.
 */
export interface DynamicFieldDefinition {
  name: keyof Pain001Model;
  label: string;
  type: FieldInputType;
  section: string;
  /** Primary source of truth for required-ness — checked before fieldConfig[].required and ALWAYS_REQUIRED_FIELDS. Leave undefined to fall through to those. */
  required?: boolean;
  options?: SelectOption[];
  placeholder?: string;
  maxLength?: number;
}

/** Field → input-type inference for the default field set. */
const FIELD_TYPE_OVERRIDES: Partial<Record<keyof Pain001Model, FieldInputType>> = {
  requestedExecutionDate: 'date',
  instructedAmount: 'number',
  chargesAmount: 'number',
  ustrdPaymentDetails: 'textarea',
  painPaymentMethodType: 'select',
  chargeBearer: 'select',
};

const FIELD_OPTIONS_OVERRIDES: Partial<Record<keyof Pain001Model, SelectOption[]>> = {
  painPaymentMethodType: PAYMENT_METHOD_OPTIONS,
  chargeBearer: CHARGE_BEARER_OPTIONS,
};

const SECTION_BY_FIELD: Partial<Record<keyof Pain001Model, string>> = {
  requestedExecutionDate: 'Payment information',
  instructedAmountCurrencyCode: 'Payment information',
  instructedAmount: 'Payment information',
  painPaymentMethodType: 'Payment information',

  debtorName: 'Debtor information',
  debtorAccountNumber: 'Debtor information',
  debtorAgentBIC: 'Debtor information',
  debtorAgentBank: 'Debtor information',

  debtorAddressLines: 'Debtor address details',
  debtorStreetName: 'Debtor address details',
  debtorBuildingNumber: 'Debtor address details',
  debtorPostalCode: 'Debtor address details',
  debtorTownName: 'Debtor address details',
  debtorCountrySubDivision: 'Debtor address details',
  debtorCountryCode: 'Debtor address details',
  debtorSortCodeUK: 'Debtor address details',
  debtorSortCodeUS: 'Debtor address details',

  creditorName: 'Creditor information',
  creditorAccount: 'Creditor information',
  creditorAgentFinancialInstitutionBIC: 'Creditor information',
  creditorAgentFinancialInstitutionName: 'Creditor information',
  creditorAgentAccountNumber: 'Creditor information',

  creditorAddressLines: 'Creditor address details',
  creditorStreetName: 'Creditor address details',
  creditorBuildingNumber: 'Creditor address details',
  creditorPostalCode: 'Creditor address details',
  creditorTownName: 'Creditor address details',
  creditorCountrySubDivision: 'Creditor address details',
  creditorCountryCode: 'Creditor address details',
  creditorSortCodeUK: 'Creditor address details',
  creditorSortCodeUS: 'Creditor address details',

  firstIntermediaryBankBIC: 'Intermediary bank details',
  firstIntermediaryBankRoutingCode: 'Intermediary bank details',
  firstIntermediaryBankName: 'Intermediary bank details',
  firstIntermediaryBankCountryCode: 'Intermediary bank details',
  firstIntermediaryBankAccountId: 'Intermediary bank details',
  secondIntermediaryBankBIC: 'Intermediary bank details',
  secondIntermediaryBankRoutingCode: 'Intermediary bank details',
  secondIntermediaryBankName: 'Intermediary bank details',
  secondIntermediaryBankCountryCode: 'Intermediary bank details',
  secondIntermediaryBankAccountId: 'Intermediary bank details',

  ustrdPaymentDetails: 'Additional details',

  chargeBearer: 'Charge details',
  chargesAmount: 'Charge details',
  chargesAgentBIC: 'Charge details',
};

/** Default field set — derived from PAIN001_FIELD_DEFINITIONS, not hand-duplicated. */
export const DEFAULT_PAYMENT_FIELDS: DynamicFieldDefinition[] = PAIN001_FIELD_DEFINITIONS
  .filter(([, fieldName]) => SECTION_BY_FIELD[fieldName as keyof Pain001Model])
  .map(([label, fieldName, mandatoryFlag]) => {
    const name = fieldName as keyof Pain001Model;
    return {
      name,
      label,
      type: FIELD_TYPE_OVERRIDES[name] ?? 'text',
      section: SECTION_BY_FIELD[name] as string,
      required: mandatoryFlag === 'M',
      options: FIELD_OPTIONS_OVERRIDES[name],
    };
  });

export interface SSPaymentFlowProps {
  paymentInput: PaymentComponentInput;
  /** App-level field overrides (hidden/required/label). Falls back to the library default if omitted. */
  fieldConfig?: FormFieldConfig[];
  /**
   * Which fields render, as what type, grouped under what sections.
   * Pass your own to add/remove/reorder fields or change their input type
   * dynamically. Defaults to DEFAULT_PAYMENT_FIELDS (the full known set).
   */
  fields?: DynamicFieldDefinition[];
  /**
   * Dynamic validation rules (required/visible/pattern per field, driven by
   * country/currency/payment-type conditions). Optional — without it, required-ness
   * falls back to fieldConfig + ALWAYS_REQUIRED_FIELDS only.
   */
  validationRules?: Pain001ValidationRules;
  /** Fires on every relevant change with the current data + validity, mirroring the original's continuous emitOutput(). */
  onPaymentOutput: (output: PaymentComponentOutput) => void;
  /** Fires once, specifically at the moment the form transitions from invalid to valid — for consumers that want an edge-triggered "form became valid" event rather than reading .isValid off every onPaymentOutput call. */
  onFormValid?: (data: Pain001Model) => void;
  onAmountChange?: (payload: { instructedAmount: string | number; instructedAmountCurrencyCode: string }) => void;
  getAuthToken?: () => string | null | undefined | Promise<string | null | undefined>;
}

type ToastState = { message: string; type: 'success' | 'error' } | null;

const emptyRules: Pain001ValidationRules = { version: '0', fields: {}, formRules: [] };

function getFieldConfigFor(fieldName: keyof Pain001Model, fieldConfig: FormFieldConfig[]): FormFieldConfig | undefined {
  return fieldConfig.find(f => f.fieldName === fieldName);
}

export function SSPaymentFlow({
  paymentInput,
  fieldConfig = DEFAULT_FIELD_CONFIG,
  fields = DEFAULT_PAYMENT_FIELDS,
  validationRules,
  onPaymentOutput,
  onFormValid,
  onAmountChange,
  getAuthToken,
}: SSPaymentFlowProps) {
  const {
    hideFieldsList = [],
    currency = '',
    dualBlindKeyFields = [],
    dualBlindKeyFlag = 'N',
    paymentModel = null,
    rejectedFieldList = [],
    paymentMode = 'maker',
    hardcapLimitCheckBaseUrl = '',
    addressLookupBaseUrl,
    applicationName = '',
    applicationModule = '',
  } = paymentInput ?? {};

  const resolvedAddressLookupBaseUrl = addressLookupBaseUrl || hardcapLimitCheckBaseUrl;

  const isMaker = paymentMode === 'maker';
  const isChecker = paymentMode === 'checker';
  const isRepair = paymentMode === 'repair';
  const isDualBlindKeyActive = isChecker && dualBlindKeyFlag === 'Y';

  const validator = useMemo(
    () => new GenericValidatorService(validationRules ?? emptyRules),
    [validationRules]
  );

  // Sections derived dynamically from whatever `fields` was passed — no hardcoded section list.
  const sections = useMemo(() => {
    const order: string[] = [];
    const map = new Map<string, DynamicFieldDefinition[]>();
    for (const field of fields) {
      if (!map.has(field.section)) {
        map.set(field.section, []);
        order.push(field.section);
      }
      map.get(field.section)!.push(field);
    }
    return order.map(title => ({ title, fields: map.get(title)! }));
  }, [fields]);

  // ── form state ────────────────────────────────────────────────────────
  const [formValues, setFormValues] = useState<Pain001Model>(() => {
    const base = paymentModel ?? createEmptyPain001();
    return currency && !base.instructedAmountCurrencyCode
      ? { ...base, instructedAmountCurrencyCode: currency }
      : base;
  });

  const originalValuesRef = useRef<Pain001Model>(paymentModel ?? createEmptyPain001());
  const [dualBlindKeyEntries, setDualBlindKeyEntries] = useState<Record<string, string>>({});
  const [dualBlindKeyErrors, setDualBlindKeyErrors] = useState<Record<string, string>>({});
  const [dualBlindKeyResult, setDualBlindKeyResult] = useState<'passed' | 'failed' | null>(null);

  const [errors, setErrors] = useState<Record<string, string | null>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [toast, setToast] = useState<ToastState>(null);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  const [hardcapValidating, setHardcapValidating] = useState(false);
  const [hardcapError, setHardcapError] = useState('');
  const [hardcapSuccessMessage, setHardcapSuccessMessage] = useState('');

  const wasValidRef = useRef(false);

  useEffect(() => {
    if (paymentModel) {
      originalValuesRef.current = paymentModel;
      setFormValues(paymentModel);
      setDualBlindKeyEntries({});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paymentModel]);

  const showToast = useCallback((message: string, type: 'success' | 'error') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  }, []);

  // ── field visibility / requiredness ──────────────────────────────────
  const isFieldHidden = useCallback(
    (fieldName: keyof Pain001Model) => {
      if (hideFieldsList.includes(fieldName as string)) return true;
      const cfg = getFieldConfigFor(fieldName, fieldConfig);
      if (cfg?.hidden) return true;
      if (validationRules) {
        const result = validator.evaluateFieldRules(fieldName as string, formValues as Record<string, unknown>);
        if (!result.visible) return true;
      }
      return false;
    },
    [hideFieldsList, fieldConfig, validationRules, validator, formValues]
  );

  const isFieldRequired = useCallback(
    (field: DynamicFieldDefinition) => {
      if (field.required !== undefined) return field.required;
      const cfg = getFieldConfigFor(field.name, fieldConfig);
      if (cfg?.required !== undefined) return cfg.required;
      if (ALWAYS_REQUIRED_FIELDS.includes(field.name)) return true;
      if (validationRules) {
        const result = validator.evaluateFieldRules(field.name as string, formValues as Record<string, unknown>);
        return result.required;
      }
      return false;
    },
    [fieldConfig, validationRules, validator, formValues]
  );

  const isFieldRejected = useCallback(
    (fieldName: keyof Pain001Model) => isRepair && rejectedFieldList.includes(fieldName as string),
    [isRepair, rejectedFieldList]
  );

  const isDualBlindKeyField = useCallback(
    (fieldName: keyof Pain001Model) => dualBlindKeyFields.includes(fieldName as string),
    [dualBlindKeyFields]
  );

  const isFieldDisabledForDualBlindKey = useCallback(
    (fieldName: keyof Pain001Model) => {
      if (!isDualBlindKeyActive) return false;
      return !isDualBlindKeyField(fieldName);
    },
    [isDualBlindKeyActive, isDualBlindKeyField]
  );

  const isFieldReadonly = useCallback(
    (fieldName: keyof Pain001Model) => {
      if (isChecker && !isDualBlindKeyField(fieldName)) return true;
      if (isFieldDisabledForDualBlindKey(fieldName)) return true;
      return false;
    },
    [isChecker, isDualBlindKeyField, isFieldDisabledForDualBlindKey]
  );

  // ── field value get/set ───────────────────────────────────────────────
  const getFieldValue = useCallback(
    (fieldName: keyof Pain001Model): string | number => {
      if (isDualBlindKeyActive && isDualBlindKeyField(fieldName)) {
        return dualBlindKeyEntries[fieldName as string] ?? '';
      }
      return (formValues[fieldName] as string | number) ?? '';
    },
    [isDualBlindKeyActive, isDualBlindKeyField, dualBlindKeyEntries, formValues]
  );

  const handleFieldChange = useCallback(
    (fieldName: keyof Pain001Model, value: string) => {
      if (isDualBlindKeyActive && isDualBlindKeyField(fieldName)) {
        setDualBlindKeyEntries(prev => ({ ...prev, [fieldName as string]: value }));
        return;
      }
      setFormValues(prev => ({ ...prev, [fieldName]: value }));
    },
    [isDualBlindKeyActive, isDualBlindKeyField]
  );

  const validateSingleDualBlindKeyField = useCallback(
    (fieldName: keyof Pain001Model) => {
      if (!isDualBlindKeyActive || !isDualBlindKeyField(fieldName)) return;
      const original = String(originalValuesRef.current[fieldName] ?? '').trim();
      const entered = String(dualBlindKeyEntries[fieldName as string] ?? '').trim();
      setDualBlindKeyErrors(prev => {
        const next = { ...prev };
        if (entered && entered !== original) {
          next[fieldName as string] = 'Value does not match original entry';
        } else {
          delete next[fieldName as string];
        }
        return next;
      });
    },
    [isDualBlindKeyActive, isDualBlindKeyField, dualBlindKeyEntries]
  );

  const doAllDualBlindKeysMatch = useCallback((): boolean => {
    return dualBlindKeyFields.every(fieldName => {
      const original = String(originalValuesRef.current[fieldName as keyof Pain001Model] ?? '').trim();
      const entered = String(dualBlindKeyEntries[fieldName] ?? '').trim();
      return entered !== '' && entered === original;
    });
  }, [dualBlindKeyFields, dualBlindKeyEntries]);

  const checkAllDualBlindKeysMatched = useCallback(() => {
    if (!isDualBlindKeyActive || dualBlindKeyFields.length === 0) return;
    const allMatch = doAllDualBlindKeysMatch();
    setDualBlindKeyResult(allMatch ? 'passed' : 'failed');
    showToast(
      allMatch ? 'Dual blind key verification passed' : 'Dual blind key verification failed',
      allMatch ? 'success' : 'error'
    );
  }, [isDualBlindKeyActive, dualBlindKeyFields, doAllDualBlindKeysMatch, showToast]);

  const handleFieldBlur = useCallback(
    (field: DynamicFieldDefinition) => {
      const fieldName = field.name;
      setTouched(prev => ({ ...prev, [fieldName]: true }));

      if (isDualBlindKeyActive && isDualBlindKeyField(fieldName)) {
        validateSingleDualBlindKeyField(fieldName);
        checkAllDualBlindKeysMatched();
      }

      const value = getFieldValue(fieldName);
      const result = validator.evaluateFieldRules(fieldName as string, formValues as Record<string, unknown>);
      const message = validator.validateFieldValue(value, {
        ...result,
        required: isFieldRequired(field),
      });
      setErrors(prev => ({ ...prev, [fieldName]: message }));

      if (fieldName === 'debtorAgentBIC' && String(value).length >= 6 && isMaker) {
        const countryCode = validator.extractCountryFromBIC(String(value));
        setFormValues(prev => ({ ...prev, debtorCountryCode: countryCode }));
        void lookupDebtorAddress(
          resolvedAddressLookupBaseUrl,
          {
            applicationName,
            applicationModule,
            countryCode,
            accountNumber: formValues.debtorAccountNumber,
            shortCode: String(value),
          },
          { getAuthToken }
        )
          .then(address => {
            setFormValues(prev => ({
              ...prev,
              debtorAddressLines: address.addressLine1 ?? prev.debtorAddressLines,
              debtorStreetName: address.streetName ?? prev.debtorStreetName,
              debtorTownName: address.townName ?? prev.debtorTownName,
              debtorPostalCode: address.postalCode ?? prev.debtorPostalCode,
            }));
          })
          .catch(() => undefined);
      }

      if (fieldName === 'creditorAgentFinancialInstitutionBIC' && String(value).length >= 6 && isMaker) {
        const countryCode = validator.extractCountryFromBIC(String(value));
        setFormValues(prev => ({ ...prev, creditorCountryCode: countryCode }));
        void lookupCreditorAddress(
          resolvedAddressLookupBaseUrl,
          {
            applicationName,
            applicationModule,
            countryCode,
            accountNumber: formValues.creditorAccount,
            shortCode: String(value),
          },
          { getAuthToken }
        )
          .then(address => {
            setFormValues(prev => ({
              ...prev,
              creditorAddressLines: address.addressLine1 ?? prev.creditorAddressLines,
              creditorStreetName: address.streetName ?? prev.creditorStreetName,
              creditorTownName: address.townName ?? prev.creditorTownName,
              creditorPostalCode: address.postalCode ?? prev.creditorPostalCode,
            }));
          })
          .catch(() => undefined);
      }

      if (fieldName === 'instructedAmount' && isMaker) {
        const payload = {
          instructedAmount: value,
          instructedAmountCurrencyCode: formValues.instructedAmountCurrencyCode,
        };
        onAmountChange?.(payload);
        if (value) {
          setHardcapValidating(true);
          setHardcapError('');
          verifyHardCap(
            hardcapLimitCheckBaseUrl,
            {
              currency: formValues.instructedAmountCurrencyCode,
              paymentAmount: Number(value),
              applicationName,
              applicationModule,
            },
            { getAuthToken }
          )
            .then(result => {
              if (result.amountWithinLimit) {
                setHardcapSuccessMessage('Hardcap limit check passed');
                setHardcapError('');
              } else {
                setHardcapSuccessMessage('');
                setHardcapError(`Value cannot be more than ${result.hardCapValue}`);
              }
            })
            .catch(() => setHardcapError('Unable to validate hard cap limit'))
            .finally(() => setHardcapValidating(false));
        }
      }
    },
    [
      isDualBlindKeyActive, isDualBlindKeyField, validateSingleDualBlindKeyField,
      checkAllDualBlindKeysMatched, getFieldValue, validator, formValues, isFieldRequired,
      isMaker, hardcapLimitCheckBaseUrl, resolvedAddressLookupBaseUrl, applicationName, applicationModule, onAmountChange, getAuthToken,
    ]
  );

  // ── overall validity + emitOutput ────────────────────────────────────
  useEffect(() => {
    const missing: string[] = [];
    for (const field of fields) {
      if (isFieldHidden(field.name)) continue;
      if (isFieldRequired(field)) {
        const value = isDualBlindKeyActive && isDualBlindKeyField(field.name)
          ? dualBlindKeyEntries[field.name as string]
          : formValues[field.name];
        if (value === undefined || value === null || String(value).trim() === '') {
          missing.push(field.name as string);
        }
      }
    }

    const dualBlindOk = !isDualBlindKeyActive || dualBlindKeyResult === 'passed';
    const hardcapOk = !hardcapError;
    const isValid = missing.length === 0 && dualBlindOk && hardcapOk;

    const outputMessage = !dualBlindOk
      ? 'dualBlindKey=failed'
      : hardcapError
        ? 'hardcapLimitExceeded'
        : missing.length > 0
          ? `Missing fields: ${missing.join(', ')}`
          : '';

    onPaymentOutput({
      paymentData: formValues,
      isValid,
      outputMessage,
      dualBlindKeyResult,
      isDualBlindKeyPassed: dualBlindKeyResult === 'passed',
    });

    if (isValid && !wasValidRef.current) {
      onFormValid?.(formValues);
    }
    wasValidRef.current = isValid;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [formValues, dualBlindKeyEntries, dualBlindKeyResult, hardcapError, fields]);

  const toggleSection = (title: string) => {
    setCollapsed(prev => ({ ...prev, [title]: !prev[title] }));
  };

  const fieldLabel = (field: DynamicFieldDefinition): string => {
    const cfg = getFieldConfigFor(field.name, fieldConfig);
    return cfg?.label ?? field.label;
  };

  const renderInput = (field: DynamicFieldDefinition, commonProps: {
    value: string | number;
    readOnly: boolean;
    disabled: boolean;
    onChange: (v: string) => void;
    onBlur: () => void;
    placeholder?: string;
  }) => {
    switch (field.type) {
      case 'select':
        return (
          <select
            className="lmn-form-control"
            value={commonProps.value}
            disabled={commonProps.disabled}
            onChange={e => commonProps.onChange(e.target.value)}
            onBlur={commonProps.onBlur}
          >
            <option value="">-- Select --</option>
            {(field.options ?? []).map(opt => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
        );
      case 'date':
        return (
          <input
            className="lmn-form-control"
            type="date"
            value={commonProps.value}
            readOnly={commonProps.readOnly}
            disabled={commonProps.disabled}
            onChange={e => commonProps.onChange(e.target.value)}
            onBlur={commonProps.onBlur}
          />
        );
      case 'number':
        return (
          <input
            className="lmn-form-control"
            type="number"
            value={commonProps.value}
            readOnly={commonProps.readOnly}
            disabled={commonProps.disabled}
            onChange={e => commonProps.onChange(e.target.value)}
            onBlur={commonProps.onBlur}
            placeholder={commonProps.placeholder}
          />
        );
      case 'textarea':
        return (
          <textarea
            className="lmn-form-control"
            value={commonProps.value}
            readOnly={commonProps.readOnly}
            disabled={commonProps.disabled}
            onChange={e => commonProps.onChange(e.target.value)}
            onBlur={commonProps.onBlur}
            placeholder={commonProps.placeholder}
          />
        );
      case 'text':
      default:
        return (
          <input
            className="lmn-form-control"
            type="text"
            value={commonProps.value}
            readOnly={commonProps.readOnly}
            disabled={commonProps.disabled}
            maxLength={field.maxLength}
            onChange={e => commonProps.onChange(e.target.value)}
            onBlur={commonProps.onBlur}
            placeholder={commonProps.placeholder}
          />
        );
    }
  };

  const renderField = (field: DynamicFieldDefinition) => {
    const fieldName = field.name;
    if (isFieldHidden(fieldName)) return null;

    const required = isFieldRequired(field);
    const rejected = isFieldRejected(fieldName);
    const readonly = isFieldReadonly(fieldName);
    const value = getFieldValue(fieldName);
    const error = touched[fieldName as string] ? errors[fieldName as string] : null;
    const dbkError = dualBlindKeyErrors[fieldName as string];
    const isDbkField = isDualBlindKeyActive && isDualBlindKeyField(fieldName);

    return (
      <div
        key={fieldName as string}
        className={`form-field${rejected ? ' rejected' : ''}${isDbkField ? ' repair-review-field' : ''}`}
      >
        <label className={`field-label${rejected ? ' rejected' : ''}`}>
          {fieldLabel(field)}
          {required && <span className="mandatory-indicator">*</span>}
        </label>
        {renderInput(field, {
          value,
          readOnly: readonly,
          disabled: isFieldDisabledForDualBlindKey(fieldName),
          onChange: v => handleFieldChange(fieldName, v),
          onBlur: () => handleFieldBlur(field),
          placeholder: isDbkField ? 'Re-enter value to confirm' : field.placeholder,
        })}
        {error && <div className="field-error">{error}</div>}
        {dbkError && <div className="field-error">{dbkError}</div>}
        {fieldName === 'instructedAmount' && (
          <>
            {hardcapValidating && (
              <div className="hardcap-info">
                <span className="spinner" /> Validating hardcap limit...
              </div>
            )}
            {!hardcapValidating && hardcapSuccessMessage && (
              <div className="hardcap-success">{hardcapSuccessMessage}</div>
            )}
            {!hardcapValidating && hardcapError && <div className="hardcap-error">{hardcapError}</div>}
          </>
        )}
      </div>
    );
  };

  const modeBannerLabel = isMaker ? 'Maker mode' : isChecker ? 'Checker mode' : 'Repair mode';
  const modeBannerSub = isMaker
    ? 'Editable submission'
    : isChecker
      ? 'Review and approve'
      : 'Targeted field correction';

  return (
    <div className="payment-form">
      <div className={`mode-banner mode-${paymentMode}`}>
        <span className="mode-label">{modeBannerLabel}</span>
        <span className="mode-subtitle">{modeBannerSub}</span>
      </div>

      {toast && <div className={`toast-message toast-${toast.type}`}>{toast.message}</div>}

      {sections.map(section => {
        const visibleFields = section.fields.filter(f => !isFieldHidden(f.name));
        if (visibleFields.length === 0) return null;
        const isCollapsed = !!collapsed[section.title];

        return (
          <div className="section-card" key={section.title}>
            <div
              className={`section-header section-header-toggle${isCollapsed ? ' collapsed' : ''}`}
              onClick={() => toggleSection(section.title)}
            >
              <span className="section-title">{section.title}</span>
              <span className="toggle-icon">{isCollapsed ? '+' : '−'}</span>
            </div>
            <div className={`section-body${isCollapsed ? ' collapsed' : ''}`}>
              <div className="form-row-2">
                {visibleFields.map(renderField)}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default SSPaymentFlow;
