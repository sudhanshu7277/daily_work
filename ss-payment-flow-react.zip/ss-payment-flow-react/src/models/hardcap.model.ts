export interface VerifyHardCapRequest {
  currency: string;
  paymentAmount: number;
  applicationName: string;
  applicationModule: string;
}

export interface VerifyHardCapResponse {
  amountWithinLimit: boolean;
  hardCapValue: number;
}
