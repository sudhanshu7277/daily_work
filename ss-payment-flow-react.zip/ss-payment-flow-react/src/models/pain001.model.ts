export interface Pain001Model {
  requestedExecutionDate: string;
  debtorName: string;
  debtorAccountNumber: string;
  debtorAgentBIC: string;
  debtorAgentBank: string;
  chargeBearer?: string;
  chargesAmount?: number;
  chargesAgentBIC?: string;
  chargesAgentBank?: string;
  debtorAddressLines?: string;
  debtorAddressLines1?: string;
  debtorAddressLines2?: string;
  debtorStreetName?: string;
  debtorBuildingNumber?: string;
  debtorPostalCode?: string;
  debtorTownName?: string;
  debtorCountrySubDivision?: string;
  debtorCountryCode?: string;
  debtorSortCodeUK?: string;
  debtorSortCodeUS?: string;
  debtorState?: string;
  instructedAmount: number;
  instructedAmountCurrencyCode: string;
  creditorName: string;
  creditorAccount: string;
  creditorAgentFinancialInstitutionBIC: string;
  creditorAgentFinancialInstitutionName: string;
  creditorAddressLines?: string;
  creditorAddressLines1?: string;
  creditorAddressLines2?: string;
  creditorStreetName?: string;
  creditorBuildingNumber?: string;
  creditorPostalCode?: string;
  creditorTownName?: string;
  creditorCountrySubDivision?: string;
  creditorCountryCode?: string;
  creditorSortCodeUK?: string;
  creditorSortCodeUS?: string;
  creditorState?: string;
  ustrdPaymentDetails?: string;
  painPaymentMethodType: string;
  firstIntermediaryBankBIC?: string;
  firstIntermediaryBankRoutingCode?: string;
  firstIntermediaryBankName?: string;
  firstIntermediaryBankCountryCode?: string;
  firstIntermediaryBankAccountId?: string;
  secondIntermediaryBankBIC?: string;
  secondIntermediaryBankRoutingCode?: string;
  secondIntermediaryBankName?: string;
  secondIntermediaryBankCountryCode?: string;
  secondIntermediaryBankAccountId?: string;
  applicationName?: string;
  applicationModule?: string;
  region?: string;
  creditorAgentAccountNumber?: string;
}

export const PAIN001_STRING_FIELDS: string[] = [
  'requestedExecutionDate',
  'debtorName', 'debtorAccountNumber', 'debtorAgentBIC', 'debtorAgentBank',
  'chargeBearer', 'chargesAgentBIC',
  'debtorAddressLines', 'debtorStreetName', 'debtorBuildingNumber',
  'debtorPostalCode', 'debtorTownName', 'debtorCountrySubDivision',
  'debtorCountryCode', 'debtorSortCodeUK', 'debtorSortCodeUS',
  'instructedAmountCurrencyCode',
  'creditorName', 'creditorAccount',
  'creditorAgentFinancialInstitutionBIC', 'creditorAgentFinancialInstitutionName',
  'creditorAgentAccountNumber',
  'creditorAddressLines', 'creditorStreetName', 'creditorBuildingNumber',
  'creditorPostalCode', 'creditorTownName', 'creditorCountrySubDivision',
  'creditorCountryCode', 'creditorSortCodeUK', 'creditorSortCodeUS',
  'ustrdPaymentDetails',
  'painPaymentMethodType',
  'firstIntermediaryBankBIC', 'firstIntermediaryBankRoutingCode',
  'firstIntermediaryBankName', 'firstIntermediaryBankCountryCode',
  'firstIntermediaryBankAccountId',
  'secondIntermediaryBankBIC', 'secondIntermediaryBankRoutingCode',
  'secondIntermediaryBankName', 'secondIntermediaryBankCountryCode',
  'secondIntermediaryBankAccountId',
  'applicationName', 'applicationModule', 'region', 'debtorState',
  'creditorState', 'creditorAddressLines1', 'creditorAddressLines2', 'debtorAddressLines1', 'debtorAddressLines2'
];

export const PAIN001_NUMERIC_FIELDS: string[] = [
  'instructedAmount', 'chargesAmount'
];

export const PAIN001_ARRAY_FIELDS: string[] = [];

export const PAIN001_MANDATORY_FIELDS: string[] = [
  'requestedExecutionDate',
  'debtorName', 'debtorAccountNumber', 'debtorAgentBIC',
  'instructedAmount', 'instructedAmountCurrencyCode',
  'creditorName', 'creditorAccount',
  'creditorAgentFinancialInstitutionBIC', 'creditorAgentFinancialInstitutionName',
  'creditorAgentAccountNumber',
  'painPaymentMethodType'
];

export type FieldDefinition = [string, string, 'M' | 'O'];

export const PAIN001_FIELD_DEFINITIONS: FieldDefinition[] = [
  ['Value Date', 'requestedExecutionDate', 'M'],
  ['Debtor Name', 'debtorName', 'M'],
  ['Debtor Account Number', 'debtorAccountNumber', 'M'],
  ['Debtor Agent BIC', 'debtorAgentBIC', 'M'],
  ['Debtor Agent Bank', 'debtorAgentBank', 'O'],
  ['Charge Information', 'chargeBearer', 'O'],
  ['Charges Amount', 'chargesAmount', 'O'],
  ['Charges Agent BIC', 'chargesAgentBIC', 'O'],
  ['Debtor Address Lines 1-4', 'debtorAddressLines', 'O'],
  ['Debtor Street', 'debtorStreetName', 'O'],
  ['Debtor Building Number', 'debtorBuildingNumber', 'O'],
  ['Debtor Postal Code', 'debtorPostalCode', 'O'],
  ['Debtor Town / City Name', 'debtorTownName', 'O'],
  ['Debtor State', 'debtorCountrySubDivision', 'O'],
  ['Debtor Country', 'debtorCountryCode', 'O'],
  ['Debtor Sort Code', 'debtorSortCodeUK', 'O'],
  ['Transaction Amount', 'instructedAmount', 'M'],
  ['Currency', 'instructedAmountCurrencyCode', 'M'],
  ['Creditor Name', 'creditorName', 'M'],
  ['Creditor Account Number', 'creditorAccount', 'M'],
  ['Creditor Agent BIC', 'creditorAgentFinancialInstitutionBIC', 'M'],
  ['Creditor Agent Bank Name', 'creditorAgentFinancialInstitutionName', 'M'],
  ['Creditor Agent Account Number', 'creditorAgentAccountNumber', 'M'],
  ['Creditor Address Lines 1-4', 'creditorAddressLines', 'O'],
  ['Creditor Street', 'creditorStreetName', 'O'],
  ['Creditor Building Number', 'creditorBuildingNumber', 'O'],
  ['Creditor Postal Code', 'creditorPostalCode', 'O'],
  ['Creditor Town / City Name', 'creditorTownName', 'O'],
  ['Creditor State', 'creditorCountrySubDivision', 'O'],
  ['Creditor Country', 'creditorCountryCode', 'O'],
  ['Creditor Sort Code', 'creditorSortCodeUK', 'O'],
  ['Remittance Information', 'ustrdPaymentDetails', 'O'],
  ['Payment Type (CBT, BKT, DFT)', 'painPaymentMethodType', 'M'],
  ['1st Intermediary Bank SWIFT Code', 'firstIntermediaryBankBIC', 'O'],
  ['1st Intermediary Bank Routing Code', 'firstIntermediaryBankRoutingCode', 'O'],
  ['1st Intermediary Bank Name', 'firstIntermediaryBankName', 'O'],
  ['1st Intermediary Bank Country Code', 'firstIntermediaryBankCountryCode', 'O'],
  ['1st Intermediary Account Number', 'firstIntermediaryBankAccountId', 'O'],
  ['2nd Intermediary Bank SWIFT Code', 'secondIntermediaryBankBIC', 'O'],
  ['2nd Intermediary Bank Routing Code', 'secondIntermediaryBankRoutingCode', 'O'],
  ['2nd Intermediary Bank Name', 'secondIntermediaryBankName', 'O'],
  ['2nd Intermediary Bank Country Code', 'secondIntermediaryBankCountryCode', 'O'],
  ['2nd Intermediary Account Number', 'secondIntermediaryBankAccountId', 'O'],
];

export function createEmptyPain001(): Pain001Model {
  return {
    requestedExecutionDate: '',
    debtorName: '',
    debtorAccountNumber: '',
    debtorAgentBIC: '',
    debtorAgentBank: '',
    chargeBearer: '',
    chargesAmount: 0,
    chargesAgentBIC: '',
    debtorAddressLines: '',
    debtorStreetName: '',
    debtorBuildingNumber: '',
    debtorPostalCode: '',
    debtorTownName: '',
    debtorCountrySubDivision: '',
    debtorCountryCode: '',
    debtorSortCodeUK: '',
    debtorSortCodeUS: '',
    instructedAmount: 0,
    instructedAmountCurrencyCode: '',
    creditorName: '',
    creditorAccount: '',
    creditorAgentFinancialInstitutionBIC: '',
    creditorAgentFinancialInstitutionName: '',
    creditorAgentAccountNumber: '',
    creditorAddressLines: '',
    creditorStreetName: '',
    creditorBuildingNumber: '',
    creditorPostalCode: '',
    creditorTownName: '',
    creditorCountrySubDivision: '',
    creditorCountryCode: '',
    creditorSortCodeUK: '',
    creditorSortCodeUS: '',
    ustrdPaymentDetails: '',
    painPaymentMethodType: '',
    firstIntermediaryBankBIC: '',
    firstIntermediaryBankRoutingCode: '',
    firstIntermediaryBankName: '',
    firstIntermediaryBankCountryCode: '',
    firstIntermediaryBankAccountId: '',
    secondIntermediaryBankBIC: '',
    secondIntermediaryBankRoutingCode: '',
    secondIntermediaryBankName: '',
    secondIntermediaryBankCountryCode: '',
    secondIntermediaryBankAccountId: '',
    applicationName: '',
    applicationModule: '',
    region: '',
  };
}

export interface FormFieldConfig {
  fieldName: keyof Pain001Model;
  hidden?: boolean;
  label?: string;
  required?: boolean;
  value?: any;
}

export interface HardcapCheckResponse {
  amountWithinLimit: boolean;
  hardCapValue: number;
}

export interface MakerSubmitResponse {
  success: boolean;
  transactionId: string;
  message: string;
  timestamp: string;
  status: 'PENDING_CHECKER' | 'ERROR';
}

export interface SelectOption {
  value: string;
  label: string;
}

export const CHARGE_BEARER_OPTIONS: SelectOption[] = [
  { value: 'DEBT', label: 'DEBT' },
  { value: 'CRED', label: 'CRED' },
  { value: 'SHAR', label: 'SHAR' }
];

export const PAYMENT_METHOD_OPTIONS: SelectOption[] = [
  { value: 'CBT', label: 'CBT' },
  { value: 'BKT', label: 'BKT' },
  { value: 'DFT', label: 'DFT' }
];

export const ALWAYS_REQUIRED_FIELDS: (keyof Pain001Model)[] = [
  'debtorName',
  'debtorAccountNumber',
  'debtorAgentBIC',
  'creditorName',
  'creditorAccount',
  'creditorAgentFinancialInstitutionBIC',
  'creditorAgentFinancialInstitutionName',
  'painPaymentMethodType',
  'requestedExecutionDate',
  'instructedAmountCurrencyCode',
  'instructedAmount',
  'creditorAgentAccountNumber'
];

export const DEFAULT_FIELD_CONFIG: FormFieldConfig[] = [
  { fieldName: 'requestedExecutionDate', label: 'Value Date', hidden: false, required: true },
  { fieldName: 'instructedAmountCurrencyCode', label: 'Currency', hidden: false, required: true },
  { fieldName: 'instructedAmount', label: 'Transaction Amount', hidden: false, required: true },
  { fieldName: 'debtorName', label: 'Debtor Name', hidden: false, required: true },
  { fieldName: 'debtorAccountNumber', label: 'Debtor Account Number', hidden: false, required: true },
  { fieldName: 'debtorAgentBIC', label: 'Debtor Agent BIC', hidden: false, required: true },
  { fieldName: 'debtorAgentBank', label: 'Debtor Agent Bank', hidden: false, required: false },
  { fieldName: 'debtorAddressLines', label: 'Debtor Address Line 1', hidden: false },
  { fieldName: 'debtorStreetName', label: 'Debtor Street', hidden: false },
  { fieldName: 'debtorBuildingNumber', label: 'Debtor Building Number', hidden: false },
  { fieldName: 'debtorPostalCode', label: 'Debtor Postal Code', hidden: false },
  { fieldName: 'debtorTownName', label: 'Debtor Town / City Name', hidden: false },
  { fieldName: 'debtorCountrySubDivision', label: 'Debtor State', hidden: false },
  { fieldName: 'debtorCountryCode', label: 'Debtor Country', hidden: false },
  { fieldName: 'debtorSortCodeUK', label: 'Debtor Sort Code', hidden: false },
  { fieldName: 'debtorSortCodeUS', label: 'Debtor Sort Code (US)', hidden: false },
  { fieldName: 'firstIntermediaryBankBIC', label: '1st Intermediary Bank SWIFT Code', hidden: false },
  { fieldName: 'firstIntermediaryBankRoutingCode', label: '1st Intermediary Bank Routing Code', hidden: false },
  { fieldName: 'firstIntermediaryBankName', label: '1st Intermediary Bank Name', hidden: false },
  { fieldName: 'firstIntermediaryBankCountryCode', label: '1st Intermediary Bank Country Code', hidden: false },
  { fieldName: 'firstIntermediaryBankAccountId', label: '1st Intermediary Account Number', hidden: false },
  { fieldName: 'secondIntermediaryBankBIC', label: '2nd Intermediary Bank SWIFT Code', hidden: false },
  { fieldName: 'secondIntermediaryBankRoutingCode', label: '2nd Intermediary Bank Routing Code', hidden: false },
  { fieldName: 'secondIntermediaryBankName', label: '2nd Intermediary Bank Name', hidden: false },
  { fieldName: 'secondIntermediaryBankCountryCode', label: '2nd Intermediary Bank Country Code', hidden: false },
  { fieldName: 'secondIntermediaryBankAccountId', label: '2nd Intermediary Account Number', hidden: false },
  { fieldName: 'creditorName', label: 'Creditor Name', hidden: false, required: true },
  { fieldName: 'creditorAccount', label: 'Creditor Account Number', hidden: false, required: true },
  { fieldName: 'creditorAgentFinancialInstitutionBIC', label: 'Creditor Agent BIC', hidden: false, required: false },
  { fieldName: 'creditorAgentFinancialInstitutionName', label: 'Creditor Agent Bank Name', hidden: false, required: false },
  { fieldName: 'creditorAgentAccountNumber', label: 'Creditor Agent Account Number', hidden: false, required: true },
  { fieldName: 'creditorAddressLines', label: 'Creditor Address Line 1', hidden: false },
  { fieldName: 'creditorStreetName', label: 'Creditor Street', hidden: false },
  { fieldName: 'creditorBuildingNumber', label: 'Creditor Building Number', hidden: false },
  { fieldName: 'creditorPostalCode', label: 'Creditor Postal Code', hidden: false },
  { fieldName: 'creditorTownName', label: 'Creditor Town / City Name', hidden: false },
  { fieldName: 'creditorCountrySubDivision', label: 'Creditor State', hidden: false },
  { fieldName: 'creditorCountryCode', label: 'Creditor Country', hidden: false },
  { fieldName: 'creditorSortCodeUK', label: 'Creditor Sort Code', hidden: false },
  { fieldName: 'creditorSortCodeUS', label: 'Creditor Sort Code (US)', hidden: false },
  { fieldName: 'ustrdPaymentDetails', label: 'Remittance Information', hidden: false },
  { fieldName: 'painPaymentMethodType', label: 'Payment Type (CBT, BKT, DFT)', hidden: false, required: true },
  { fieldName: 'chargeBearer', label: 'Charge Information', hidden: false },
  { fieldName: 'chargesAmount', label: 'Charges Amount', hidden: false },
  { fieldName: 'chargesAgentBIC', label: 'Charges Agent BIC', hidden: false },
  { fieldName: 'debtorState', label: 'Debtor State', hidden: false },
  { fieldName: 'creditorState', label: 'Creditor State', hidden: false },
];
