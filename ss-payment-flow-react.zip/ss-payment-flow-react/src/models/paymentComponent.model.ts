import { Pain001Model } from './pain001.model';

export type PaymentMode = 'maker' | 'checker' | 'repair';
export type DualBlindKeyFlag = 'Y' | 'N';
export type DualBlindKeyResult = 'passed' | 'failed' | null;

export interface PaymentComponentInput {
  applicationName: string;
  applicationModule: string;
  hideFieldsList: string[];
  currency: string;
  dualBlindKeyFields: string[];
  dualBlindKeyFlag: DualBlindKeyFlag;
  paymentModel: Pain001Model | null;
  rejectedFieldList: string[];
  paymentMode: PaymentMode;
  hardcapLimitCheckBaseUrl: string;
  /**
   * Base URL for debtor/creditor address lookup. Separate field because we
   * never saw the real ss-payment-flow.component.ts to confirm whether the
   * original passed the same base URL as hardcap or a distinct one — treat
   * this as an assumption, not a verified match to source. Falls back to
   * hardcapLimitCheckBaseUrl if left unset (see SSPaymentFlow.tsx).
   */
  addressLookupBaseUrl?: string;
  makerSubmitUrl: string;
  region: string;
  useMockApi: boolean;
}

export interface PaymentComponentOutput {
  paymentData: Pain001Model;
  isValid: boolean;
  outputMessage: string;
  dualBlindKeyResult: DualBlindKeyResult;
  isDualBlindKeyPassed: boolean;
}

export interface DualBlindKeyEntry {
  fieldName: string;
  checkerValue: string;
}

export function createDefaultPaymentInput(): PaymentComponentInput {
  return {
    applicationName: '',
    applicationModule: '',
    hideFieldsList: [],
    currency: '',
    dualBlindKeyFields: [],
    dualBlindKeyFlag: 'N',
    paymentModel: null,
    rejectedFieldList: [],
    paymentMode: 'maker',
    hardcapLimitCheckBaseUrl: '',
    addressLookupBaseUrl: '',
    makerSubmitUrl: '',
    region: '',
    useMockApi: false,
  };
}
