/**
 * Generic Validation Rule Model for pain.001 fields.
 * Supports dynamic validation driven by JSON metadata.
 * Rules are evaluated by priority (lowest number = highest priority).
 * The first matching rule wins for each field.
 */

/** A single condition that must be true for a rule to apply. */
export interface ValidationCondition {
  /** Category of the condition factor. */
  factor: 'country' | 'paymentType' | 'currency' | 'paymentMethod' | 'fieldValue';
  /** The form control whose value is inspected. */
  sourceField: string;
  /** Optional derivation to apply before comparison (e.g. extract country from BIC). */
  derivation?: 'bicCountry';
  /** Comparison operator. */
  operator: 'eq' | 'neq' | 'in' | 'notIn' | 'empty' | 'notEmpty';
  /** Expected value(s) - string for eq/neq, string[] for in/notIn, omitted for empty/notEmpty. */
  value?: string | string[];
}

/** The effect to apply when all conditions of a rule match. */
export interface ValidationEffect {
  /** Whether the field becomes required. */
  required?: boolean;
  /** Whether the field is visible. */
  visible?: boolean;
  /** Regex pattern string the value must match. */
  pattern?: string;
  /** Human-readable message shown when pattern fails. */
  patternMessage?: string;
  /** Maximum allowed string length. */
  maxLength?: number;
  /** Number of allowed decimal places (for numeric fields). */
  decimalPlaces?: number;
}

/** A single field-level validation rule entry. */
export interface FieldValidationRule {
  /** Evaluation order - lower number = higher priority. First match wins. */
  priority: number;
  /** All conditions must be true for this rule to apply (AND logic). */
  conditions: ValidationCondition[];
  /** The validation effect applied when all conditions match. */
  effect: ValidationEffect;
}

/** A cross-field (form-level) rule that watches multiple fields. */
export interface FormRule {
  /** Unique rule identifier. */
  id: string;
  /** Human-readable description. */
  description: string;
  /** Fields whose changes trigger re-evaluation of this rule. */
  watchFields: string[];
  /** All conditions must be true (AND). */
  conditions: ValidationCondition[];
  /** Map of fieldName -> effect to apply when conditions are met. */
  effects: Record<string, ValidationEffect>;
}

/** Top-level validation rules document loaded from JSON or API. */
export interface Pain001ValidationRules {
  version: string;
  /** Field-level rules keyed by form control name. */
  fields: Record<string, FieldValidationRule[]>;
  /** Cross-field rules evaluated on form changes. */
  formRules: FormRule[];
}

/** Result of evaluating validation rules for a single field. */
export interface FieldValidationResult {
  fieldName: string;
  required: boolean;
  visible: boolean;
  pattern?: string;
  patternMessage?: string;
  maxLength?: number;
  decimalPlaces?: number;
}
