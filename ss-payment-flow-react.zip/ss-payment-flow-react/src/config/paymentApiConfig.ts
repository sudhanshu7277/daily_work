/**
 * Base URL configuration for the PAYMENT COMPONENT's own Java backend —
 * deliberately kept separate from GAB's own API configuration.
 *
 * The original Angular library called its own backend (its own `environment.apiUrl`,
 * its own hard-cap service host, etc.), which is NOT necessarily the same domain/base
 * URL that GAB's own APIs live on. Do not reuse GAB's existing axios/fetch instance
 * or its own API base URL for these calls — wire this config to the payment
 * backend's actual host(s) instead.
 *
 * Env var names are prefixed PAYMENT_ specifically so they can't collide with or
 * be confused for GAB's own API env vars in the same .env file. Adjust the
 * `process.env.REACT_APP_*` reads below to match whatever env-var convention
 * GAB actually uses (Vite uses import.meta.env.VITE_*, CRA uses
 * process.env.REACT_APP_*, etc.) — I don't know which build tool GAB is on.
 */
export interface PaymentApiConfig {
  /** Base URL for maker submission + checker approval endpoints (createMakerPayment, checker/approve). */
  apiBaseUrl: string;
  /** Base URL for the hard-cap check endpoint. Was environment.apiUrl in the Angular HardcapService. */
  hardcapLimitCheckBaseUrl: string;
  /** Base URL for debtor/creditor address lookup endpoints. */
  addressLookupBaseUrl: string;
  /** Endpoint the maker form ultimately submits to, if distinct from apiBaseUrl + a fixed path. */
  makerSubmitUrl: string;
}

/**
 * Reads payment-specific env vars. If GAB uses a different env-var convention
 * (Vite's import.meta.env, a runtime-injected window.__CONFIG__, etc.), swap
 * this out for that pattern — the important part is that these four values
 * come from config distinct from GAB's own API base URL, not derived from it.
 */
export function getPaymentApiConfig(): PaymentApiConfig {
  return {
    apiBaseUrl: process.env.REACT_APP_PAYMENT_API_BASE_URL ?? '',
    hardcapLimitCheckBaseUrl: process.env.REACT_APP_PAYMENT_HARDCAP_BASE_URL ?? '',
    addressLookupBaseUrl: process.env.REACT_APP_PAYMENT_ADDRESS_BASE_URL ?? '',
    makerSubmitUrl: process.env.REACT_APP_PAYMENT_MAKER_SUBMIT_URL ?? '',
  };
}
